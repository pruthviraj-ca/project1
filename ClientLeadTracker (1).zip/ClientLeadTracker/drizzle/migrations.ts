import { drizzle } from "drizzle-orm/neon-serverless";
import { migrate } from "drizzle-orm/neon-serverless/migrator";
import { Pool, neonConfig } from '@neondatabase/serverless';
import ws from "ws";

neonConfig.webSocketConstructor = ws;

// This script runs database migrations to sync the database with our schema
async function main() {
  if (!process.env.DATABASE_URL) {
    throw new Error(
      "DATABASE_URL must be set. Did you forget to provision a database?",
    );
  }

  console.log("Running database migrations...");
  const pool = new Pool({ connectionString: process.env.DATABASE_URL });
  const db = drizzle(pool);

  // This will automatically run needed migrations on the database
  await migrate(db, { migrationsFolder: "drizzle/migrations" });
  
  console.log("Migrations completed successfully");
  await pool.end();
}

main().catch((err) => {
  console.error("Migration failed:");
  console.error(err);
  process.exit(1);
});