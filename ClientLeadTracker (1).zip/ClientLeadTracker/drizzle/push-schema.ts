import { drizzle } from "drizzle-orm/neon-serverless";
import { Pool, neonConfig } from '@neondatabase/serverless';
import ws from "ws";
import * as schema from "../shared/schema";

// For neon database
neonConfig.webSocketConstructor = ws;

// This script directly creates tables based on our schema definitions
async function main() {
  if (!process.env.DATABASE_URL) {
    throw new Error(
      "DATABASE_URL must be set. Did you forget to provision a database?",
    );
  }

  console.log("Pushing schema to database...");
  
  try {
    const pool = new Pool({ connectionString: process.env.DATABASE_URL });
    const db = drizzle(pool, { schema });

    // Create users table
    console.log("Creating users table...");
    await pool.query(`
      CREATE TABLE IF NOT EXISTS users (
        id SERIAL PRIMARY KEY,
        username TEXT NOT NULL UNIQUE,
        password TEXT NOT NULL,
        email TEXT NOT NULL,
        role TEXT NOT NULL,
        name TEXT NOT NULL
      )
    `);

    // Create clients table
    console.log("Creating clients table...");
    await pool.query(`
      CREATE TABLE IF NOT EXISTS clients (
        id SERIAL PRIMARY KEY,
        email TEXT NOT NULL,
        name TEXT NOT NULL,
        status TEXT NOT NULL,
        unique_id TEXT NOT NULL UNIQUE,
        phone TEXT NOT NULL,
        inquiry_time TIMESTAMP NOT NULL,
        assigned_to INTEGER REFERENCES users(id),
        is_settled BOOLEAN NOT NULL DEFAULT false
      )
    `);

    // Create properties table
    console.log("Creating properties table...");
    await pool.query(`
      CREATE TABLE IF NOT EXISTS properties (
        id SERIAL PRIMARY KEY,
        unique_id TEXT NOT NULL UNIQUE,
        flat_type TEXT NOT NULL,
        builder_name TEXT NOT NULL,
        flat_number TEXT NOT NULL,
        address TEXT NOT NULL,
        is_available BOOLEAN NOT NULL DEFAULT true
      )
    `);

    // Create interactions table
    console.log("Creating interactions table...");
    await pool.query(`
      CREATE TABLE IF NOT EXISTS interactions (
        id SERIAL PRIMARY KEY,
        status TEXT NOT NULL,
        client_id INTEGER NOT NULL REFERENCES clients(id),
        employee_id INTEGER NOT NULL REFERENCES users(id),
        interaction_type TEXT NOT NULL,
        notes TEXT,
        timestamp TIMESTAMP NOT NULL DEFAULT NOW()
      )
    `);

    // Create follow_ups table
    console.log("Creating follow_ups table...");
    await pool.query(`
      CREATE TABLE IF NOT EXISTS follow_ups (
        id SERIAL PRIMARY KEY,
        client_id INTEGER NOT NULL REFERENCES clients(id),
        employee_id INTEGER NOT NULL REFERENCES users(id),
        notes TEXT,
        scheduled_time TIMESTAMP NOT NULL,
        completed BOOLEAN NOT NULL DEFAULT false
      )
    `);

    // Create site_visits table
    console.log("Creating site_visits table...");
    await pool.query(`
      CREATE TABLE IF NOT EXISTS site_visits (
        id SERIAL PRIMARY KEY,
        client_id INTEGER NOT NULL REFERENCES clients(id),
        employee_id INTEGER NOT NULL REFERENCES users(id),
        notes TEXT,
        scheduled_time TIMESTAMP NOT NULL,
        completed BOOLEAN NOT NULL DEFAULT false,
        property_id INTEGER NOT NULL REFERENCES properties(id)
      )
    `);

    // Create settlements table
    console.log("Creating settlements table...");
    await pool.query(`
      CREATE TABLE IF NOT EXISTS settlements (
        id SERIAL PRIMARY KEY,
        client_id INTEGER NOT NULL REFERENCES clients(id),
        employee_id INTEGER NOT NULL REFERENCES users(id),
        notes TEXT,
        property_id INTEGER NOT NULL REFERENCES properties(id),
        settlement_date TIMESTAMP NOT NULL DEFAULT NOW()
      )
    `);

    console.log("Schema push completed successfully!");
    await pool.end();
    
  } catch (error) {
    console.error("Schema push failed:", error);
  }
}

main();