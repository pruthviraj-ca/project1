import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import { Bar } from 'react-chartjs-2';

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
);

interface LeadStatusChartProps {
  hot: number;
  warm: number;
  cold: number;
  total: number;
}

export default function LeadStatusChart({ hot, warm, cold, total }: LeadStatusChartProps) {
  // Calculate percentages
  const hotPercent = total > 0 ? Math.round((hot / total) * 100) : 0;
  const warmPercent = total > 0 ? Math.round((warm / total) * 100) : 0;
  const coldPercent = total > 0 ? Math.round((cold / total) * 100) : 0;
  
  const options = {
    indexAxis: 'y' as const,
    elements: {
      bar: {
        borderWidth: 0,
        borderRadius: 4,
      },
    },
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false,
      },
      tooltip: {
        callbacks: {
          label: function(context: any) {
            return `${context.raw}%`;
          }
        }
      },
    },
    scales: {
      y: {
        grid: {
          display: false,
          drawBorder: false,
        },
      },
      x: {
        min: 0,
        max: 100,
        grid: {
          display: false,
          drawBorder: false,
        },
        ticks: {
          callback: function(value: any) {
            return value + '%';
          }
        }
      },
    },
  };
  
  const data = {
    labels: ['Hot Leads', 'Warm Leads', 'Cold Leads'],
    datasets: [
      {
        data: [hotPercent, warmPercent, coldPercent],
        backgroundColor: [
          'rgba(239, 68, 68, 0.8)', // hot - red
          'rgba(245, 158, 11, 0.8)', // warm - yellow
          'rgba(59, 130, 246, 0.8)', // cold - blue
        ],
      },
    ],
  };
  
  return (
    <div className="space-y-4">
      <div className="h-48">
        <Bar options={options} data={data} />
      </div>
      <div className="grid grid-cols-3 gap-2 text-center">
        <div>
          <p className="text-xs font-medium text-gray-500">Hot</p>
          <p className="text-lg font-medium text-gray-900">{hot}</p>
        </div>
        <div>
          <p className="text-xs font-medium text-gray-500">Warm</p>
          <p className="text-lg font-medium text-gray-900">{warm}</p>
        </div>
        <div>
          <p className="text-xs font-medium text-gray-500">Cold</p>
          <p className="text-lg font-medium text-gray-900">{cold}</p>
        </div>
      </div>
    </div>
  );
}
