import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import {
  LayoutDashboard,
  Users,
  Building,
  Upload,
  Calendar,
  Settings,
  LogOut,
  Menu,
  X,
  ChevronRight,
  Share,
  ChevronDown,
  BarChart,
} from "lucide-react";
import { cn } from "@/lib/utils";

interface SidebarLinkProps {
  href: string;
  icon: React.ReactNode;
  children: React.ReactNode;
  onClick?: () => void;
  active?: boolean;
}

function SidebarLink({ href, icon, children, onClick, active }: SidebarLinkProps) {
  return (
    <Link href={href}>
      <a
        className={cn(
          "flex items-center py-2 px-4 text-sm font-medium rounded-md transition-colors",
          active
            ? "bg-primary/10 text-primary"
            : "text-gray-700 hover:bg-gray-100 hover:text-gray-900"
        )}
        onClick={onClick}
      >
        {icon}
        <span className="ml-3">{children}</span>
      </a>
    </Link>
  );
}

export function Sidebar() {
  const [location] = useLocation();
  const { user, logoutMutation } = useAuth();
  const [mobileOpen, setMobileOpen] = useState(false);
  
  const toggleMobileMenu = () => {
    setMobileOpen(!mobileOpen);
  };
  
  const handleLogout = () => {
    logoutMutation.mutate();
  };
  
  // Check if current path matches or starts with the path
  const isActive = (path: string) => {
    return location === path || (path !== "/" && location.startsWith(path));
  };
  
  const isManager = user?.role === "manager";
  
  return (
    <>
      {/* Mobile menu button */}
      <div className="fixed top-4 left-4 z-40 lg:hidden">
        <Button
          variant="outline"
          size="icon"
          onClick={toggleMobileMenu}
          className="bg-white"
        >
          {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </Button>
      </div>
      
      {/* Mobile overlay */}
      {mobileOpen && (
        <div 
          className="fixed inset-0 z-30 bg-black/20 lg:hidden"
          onClick={() => setMobileOpen(false)}
        />
      )}
      
      {/* Sidebar */}
      <div 
        className={cn(
          "fixed inset-y-0 left-0 z-30 w-64 transform bg-white border-r border-gray-200 transition-transform duration-200 ease-in-out lg:translate-x-0 lg:static lg:inset-auto lg:w-72",
          mobileOpen ? "translate-x-0" : "-translate-x-full"
        )}
      >
        <div className="flex flex-col h-full">
          {/* Sidebar header */}
          <div className="flex items-center justify-between p-4">
            <Link href={isManager ? "/manager" : "/employee"}>
              <a className="inline-flex items-center space-x-2">
                <Building className="h-8 w-8 text-primary" />
                <span className="text-xl font-bold text-primary">PropertySmart</span>
              </a>
            </Link>
            <Button
              variant="ghost"
              size="icon"
              onClick={toggleMobileMenu}
              className="lg:hidden"
            >
              <X className="h-5 w-5" />
            </Button>
          </div>
          
          <Separator />
          
          {/* Sidebar content */}
          <div className="flex-1 py-4 overflow-y-auto">
            <nav className="px-2 space-y-1">
              {isManager ? (
                // Manager navigation
                <>
                  <SidebarLink 
                    href="/manager" 
                    icon={<LayoutDashboard className="h-5 w-5" />}
                    active={isActive("/manager")}
                  >
                    Dashboard
                  </SidebarLink>
                  
                  <SidebarLink 
                    href="/manager/upload" 
                    icon={<Upload className="h-5 w-5" />}
                    active={isActive("/manager/upload")}
                  >
                    Upload Data
                  </SidebarLink>
                  
                  <SidebarLink 
                    href="/manager/distribute" 
                    icon={<Share className="h-5 w-5" />}
                    active={isActive("/manager/distribute")}
                  >
                    Distribute Leads
                  </SidebarLink>
                  
                  <SidebarLink 
                    href="/manager/leads" 
                    icon={<Users className="h-5 w-5" />}
                    active={isActive("/manager/leads")}
                  >
                    All Leads
                  </SidebarLink>
                  
                  <SidebarLink 
                    href="/manager/properties" 
                    icon={<Building className="h-5 w-5" />}
                    active={isActive("/manager/properties")}
                  >
                    Properties
                  </SidebarLink>
                  
                  <SidebarLink 
                    href="/manager/analytics" 
                    icon={<BarChart className="h-5 w-5" />}
                    active={isActive("/manager/analytics")}
                  >
                    Analytics
                  </SidebarLink>
                </>
              ) : (
                // Employee navigation
                <>
                  <SidebarLink 
                    href="/employee" 
                    icon={<LayoutDashboard className="h-5 w-5" />}
                    active={isActive("/employee") && !isActive("/employee/client/")}
                  >
                    Dashboard
                  </SidebarLink>
                  
                  <SidebarLink 
                    href="/employee/calendar" 
                    icon={<Calendar className="h-5 w-5" />}
                    active={isActive("/employee/calendar")}
                  >
                    My Calendar
                  </SidebarLink>
                  
                  <SidebarLink 
                    href="/employee/properties" 
                    icon={<Building className="h-5 w-5" />}
                    active={isActive("/employee/properties")}
                  >
                    Properties
                  </SidebarLink>
                </>
              )}
            </nav>
          </div>
          
          {/* User info & logout */}
          <div className="p-4 border-t border-gray-200">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <div className="h-9 w-9 rounded-full bg-primary/10 flex items-center justify-center">
                  <span className="text-sm font-medium text-primary">
                    {user?.name.split(' ').map(n => n[0]).join('')}
                  </span>
                </div>
              </div>
              <div className="ml-3 min-w-0 flex-1">
                <p className="text-sm font-medium text-gray-900 truncate">{user?.name}</p>
                <p className="text-xs text-gray-500 truncate capitalize">{user?.role}</p>
              </div>
              <Button variant="ghost" size="icon" onClick={handleLogout}>
                <LogOut className="h-5 w-5 text-gray-500" />
              </Button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
