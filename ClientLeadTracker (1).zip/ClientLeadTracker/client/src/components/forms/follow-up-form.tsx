import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { format } from "date-fns";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { CalendarIcon, Clock } from "lucide-react";
import { cn } from "@/lib/utils";

interface FollowUpFormProps {
  clientId: number;
  employeeId: number;
  existingFollowUps: any[];
}

const followUpSchema = z.object({
  scheduledDate: z.date({
    required_error: "Please select a date",
  }),
  scheduledTime: z.string({
    required_error: "Please select a time",
  }),
  notes: z.string().optional(),
});

type FollowUpFormValues = z.infer<typeof followUpSchema>;

export function FollowUpForm({ clientId, employeeId, existingFollowUps }: FollowUpFormProps) {
  const { toast } = useToast();
  const [upcomingFollowUps, setUpcomingFollowUps] = useState<any[]>(
    existingFollowUps.filter(
      (fu) => !fu.completed && new Date(fu.scheduledTime) > new Date()
    ).sort(
      (a, b) => new Date(a.scheduledTime).getTime() - new Date(b.scheduledTime).getTime()
    )
  );

  const followUpMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest("POST", "/api/followups", data);
      return await res.json();
    },
    onSuccess: (data) => {
      // Add the new follow-up to the list
      setUpcomingFollowUps([
        ...upcomingFollowUps,
        data
      ].sort(
        (a, b) => new Date(a.scheduledTime).getTime() - new Date(b.scheduledTime).getTime()
      ));
      
      // Invalidate relevant queries
      queryClient.invalidateQueries({ queryKey: ["/api/clients", clientId, "followups"] });
      queryClient.invalidateQueries({ queryKey: ["/api/employees", employeeId, "followups/today"] });
      
      toast({
        title: "Follow-up scheduled",
        description: "Your follow-up has been scheduled successfully",
      });
      
      // Reset the form
      form.reset({
        scheduledDate: new Date(),
        scheduledTime: "09:00",
        notes: "",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to schedule follow-up",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Set up form with default values
  const form = useForm<FollowUpFormValues>({
    resolver: zodResolver(followUpSchema),
    defaultValues: {
      scheduledDate: new Date(),
      scheduledTime: "09:00",
      notes: "",
    },
  });
  
  // Submit handler
  function onSubmit(values: FollowUpFormValues) {
    const [hours, minutes] = values.scheduledTime.split(":").map(Number);
    const scheduledTime = new Date(values.scheduledDate);
    scheduledTime.setHours(hours, minutes, 0, 0);
    
    // Check if the scheduled time is in the past
    if (scheduledTime < new Date()) {
      toast({
        title: "Invalid time",
        description: "Follow-up time cannot be in the past",
        variant: "destructive",
      });
      return;
    }
    
    followUpMutation.mutate({
      clientId,
      employeeId,
      scheduledTime: scheduledTime.toISOString(),
      completed: false,
      notes: values.notes,
    });
  }
  
  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-medium mb-4">Schedule a Follow-up</h3>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <div className="flex flex-col space-y-4 sm:flex-row sm:space-y-0 sm:space-x-4">
              <FormField
                control={form.control}
                name="scheduledDate"
                render={({ field }) => (
                  <FormItem className="flex-1">
                    <FormLabel>Date</FormLabel>
                    <Popover>
                      <PopoverTrigger asChild>
                        <FormControl>
                          <Button
                            variant="outline"
                            className={cn(
                              "w-full pl-3 text-left font-normal",
                              !field.value && "text-muted-foreground"
                            )}
                          >
                            {field.value ? (
                              format(field.value, "PPP")
                            ) : (
                              <span>Pick a date</span>
                            )}
                            <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                          </Button>
                        </FormControl>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={field.value}
                          onSelect={field.onChange}
                          disabled={(date) => date < new Date(new Date().setHours(0, 0, 0, 0))}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="scheduledTime"
                render={({ field }) => (
                  <FormItem className="flex-1">
                    <FormLabel>Time</FormLabel>
                    <FormControl>
                      <Input
                        type="time"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <FormField
              control={form.control}
              name="notes"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Notes</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Add any notes about the follow-up..."
                      className="resize-none"
                      {...field}
                    />
                  </FormControl>
                  <FormDescription>
                    Include any specific topics to discuss or questions to ask.
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <Button 
              type="submit" 
              className="w-full sm:w-auto"
              disabled={followUpMutation.isPending}
            >
              {followUpMutation.isPending ? "Scheduling..." : "Schedule Follow-up"}
            </Button>
          </form>
        </Form>
      </div>
      
      {/* Upcoming Follow-ups */}
      <div>
        <h3 className="text-lg font-medium mb-4">Upcoming Follow-ups</h3>
        {upcomingFollowUps.length === 0 ? (
          <p className="text-gray-500">No upcoming follow-ups scheduled</p>
        ) : (
          <div className="space-y-3">
            {upcomingFollowUps.map((followUp) => (
              <Card key={followUp.id}>
                <CardContent className="p-4">
                  <div className="flex justify-between items-start">
                    <div>
                      <div className="flex items-center">
                        <Clock className="h-4 w-4 text-primary mr-2" />
                        <p className="font-medium">
                          {format(new Date(followUp.scheduledTime), "PPP")} at {format(new Date(followUp.scheduledTime), "h:mm a")}
                        </p>
                      </div>
                      {followUp.notes && (
                        <p className="text-sm text-gray-600 mt-2">{followUp.notes}</p>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
