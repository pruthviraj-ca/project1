import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { InteractionTypeEnum, LeadStatusEnum } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface InteractionFormProps {
  clientId: number;
  employeeId: number;
}

const interactionSchema = z.object({
  interactionType: InteractionTypeEnum,
  status: LeadStatusEnum,
  notes: z.string().min(1, "Notes are required").max(500, "Notes must be less than 500 characters"),
});

type InteractionFormValues = z.infer<typeof interactionSchema>;

export function InteractionForm({ clientId, employeeId }: InteractionFormProps) {
  const { toast } = useToast();
  const [showFollowUpForm, setShowFollowUpForm] = useState(false);
  
  const interactionMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest("POST", "/api/interactions", data);
      return await res.json();
    },
    onSuccess: (data) => {
      // Invalidate relevant queries
      queryClient.invalidateQueries({ queryKey: ["/api/clients", clientId, "interactions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/clients", clientId] });
      
      toast({
        title: "Interaction logged",
        description: "Your interaction has been logged successfully",
      });
      
      setShowFollowUpForm(true);
      
      // Reset the form
      form.reset({
        interactionType: "call",
        status: form.getValues().status, // Keep the current status
        notes: "",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to log interaction",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Set up form with default values
  const form = useForm<InteractionFormValues>({
    resolver: zodResolver(interactionSchema),
    defaultValues: {
      interactionType: "call",
      status: "cold",
      notes: "",
    },
  });
  
  // Submit handler
  function onSubmit(values: InteractionFormValues) {
    interactionMutation.mutate({
      clientId,
      employeeId,
      interactionType: values.interactionType,
      status: values.status,
      notes: values.notes,
      timestamp: new Date().toISOString(),
    });
  }
  
  return (
    <div>
      <h3 className="text-sm font-medium text-gray-900 mb-3">Log New Interaction</h3>
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <FormField
            control={form.control}
            name="interactionType"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Type</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Select interaction type" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="call">Phone Call</SelectItem>
                    <SelectItem value="email">Email</SelectItem>
                    <SelectItem value="whatsapp">WhatsApp</SelectItem>
                    <SelectItem value="site-visit">Site Visit</SelectItem>
                    <SelectItem value="office-visit">Office Visit</SelectItem>
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="status"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Update Status</FormLabel>
                <FormControl>
                  <RadioGroup
                    onValueChange={field.onChange}
                    defaultValue={field.value}
                    className="flex space-x-4"
                  >
                    <FormItem className="flex items-center space-x-2 space-y-0">
                      <FormControl>
                        <RadioGroupItem value="hot" />
                      </FormControl>
                      <FormLabel className="font-normal text-red-600">Hot</FormLabel>
                    </FormItem>
                    <FormItem className="flex items-center space-x-2 space-y-0">
                      <FormControl>
                        <RadioGroupItem value="warm" />
                      </FormControl>
                      <FormLabel className="font-normal text-yellow-600">Warm</FormLabel>
                    </FormItem>
                    <FormItem className="flex items-center space-x-2 space-y-0">
                      <FormControl>
                        <RadioGroupItem value="cold" />
                      </FormControl>
                      <FormLabel className="font-normal text-blue-600">Cold</FormLabel>
                    </FormItem>
                  </RadioGroup>
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="notes"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Notes</FormLabel>
                <FormControl>
                  <Textarea
                    placeholder="Add notes about the interaction..."
                    className="resize-none"
                    {...field}
                  />
                </FormControl>
                <FormDescription>
                  Include details of the conversation, client preferences, and requirements.
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <div className="flex justify-end space-x-3">
            <Button 
              type="submit" 
              disabled={interactionMutation.isPending}
            >
              {interactionMutation.isPending ? "Saving..." : "Save & Schedule Follow-up"}
            </Button>
            <Button 
              type="button" 
              variant="outline"
              onClick={() => form.handleSubmit(onSubmit)()}
              disabled={interactionMutation.isPending}
            >
              Save Only
            </Button>
          </div>
        </form>
      </Form>
    </div>
  );
}
