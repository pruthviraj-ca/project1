import { useState } from "react";
import { useLocation } from "wouter";
import { format } from "date-fns";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { 
  Pagination, 
  PaginationContent, 
  PaginationItem, 
  PaginationLink, 
  PaginationNext, 
  PaginationPrevious 
} from "@/components/ui/pagination";
import StatusBadge from "@/components/leads/status-badge";
import { Eye, Phone, Calendar } from "lucide-react";

interface Client {
  id: number;
  name: string;
  email: string;
  phone: string;
  inquiryTime: string;
  status: string;
  uniqueId: string;
}

interface LeadTableProps {
  clients: Client[];
  isLoading: boolean;
  pageSize?: number;
}

export function LeadTable({ clients, isLoading, pageSize = 10 }: LeadTableProps) {
  const [location, navigate] = useLocation();
  const [currentPage, setCurrentPage] = useState(1);
  
  if (isLoading) {
    return (
      <div className="text-center py-8">
        <p>Loading clients...</p>
      </div>
    );
  }
  
  if (!clients?.length) {
    return (
      <div className="text-center py-8">
        <p className="text-gray-500">No clients found.</p>
      </div>
    );
  }
  
  // Pagination
  const totalPages = Math.ceil(clients.length / pageSize);
  const paginatedClients = clients.slice(
    (currentPage - 1) * pageSize, 
    currentPage * pageSize
  );
  
  return (
    <div>
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Client</TableHead>
              <TableHead>Contact</TableHead>
              <TableHead>Inquiry Date</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Next Follow-up</TableHead>
              <TableHead>Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {paginatedClients.map((client) => (
              <TableRow key={client.id}>
                <TableCell>
                  <div className="flex items-center">
                    <div 
                      className={`flex-shrink-0 h-10 w-10 rounded-full flex items-center justify-center mr-3
                        ${client.status === 'hot' ? 'bg-red-100' : 
                          client.status === 'warm' ? 'bg-yellow-100' : 
                            client.status === 'cold' ? 'bg-blue-100' : 'bg-gray-100'}`}
                    >
                      <span 
                        className={`font-medium text-xs
                          ${client.status === 'hot' ? 'text-red-800' : 
                            client.status === 'warm' ? 'text-yellow-800' : 
                              client.status === 'cold' ? 'text-blue-800' : 'text-gray-800'}`}
                      >
                        {client.name.split(' ').map(n => n[0]).join('')}
                      </span>
                    </div>
                    <div>
                      <div className="text-sm font-medium text-gray-900">{client.name}</div>
                      <div className="text-xs text-gray-500">ID: {client.uniqueId}</div>
                    </div>
                  </div>
                </TableCell>
                <TableCell>
                  <div className="text-sm text-gray-900">{client.phone}</div>
                  <div className="text-sm text-gray-500">{client.email}</div>
                </TableCell>
                <TableCell>
                  <div className="text-sm text-gray-900">
                    {format(new Date(client.inquiryTime), "MMM d, yyyy")}
                  </div>
                </TableCell>
                <TableCell>
                  <StatusBadge status={client.status} />
                </TableCell>
                <TableCell>
                  <div className="text-sm text-gray-900">
                    {/* This would come from followups data in a real implementation */}
                    {Math.random() > 0.7 ? (
                      <span className="text-red-600 font-medium">Missed</span>
                    ) : (
                      format(new Date(
                        Date.now() + Math.floor(Math.random() * 7 * 24 * 60 * 60 * 1000)
                      ), "MMM d, h:mm a")
                    )}
                  </div>
                </TableCell>
                <TableCell>
                  <div className="flex space-x-2">
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8 text-primary"
                      onClick={() => navigate(`/employee/client/${client.id}`)}
                    >
                      <Eye className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8 text-green-600"
                    >
                      <Phone className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8 text-gray-600"
                    >
                      <Calendar className="h-4 w-4" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
      
      {totalPages > 1 && (
        <div className="mt-4">
          <Pagination>
            <PaginationContent>
              <PaginationItem>
                <PaginationPrevious 
                  onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                  disabled={currentPage === 1}
                />
              </PaginationItem>
              
              {Array.from({ length: totalPages }).map((_, i) => (
                <PaginationItem key={i + 1}>
                  <PaginationLink
                    isActive={currentPage === i + 1}
                    onClick={() => setCurrentPage(i + 1)}
                  >
                    {i + 1}
                  </PaginationLink>
                </PaginationItem>
              ))}
              
              <PaginationItem>
                <PaginationNext 
                  onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                  disabled={currentPage === totalPages} 
                />
              </PaginationItem>
            </PaginationContent>
          </Pagination>
        </div>
      )}
    </div>
  );
}
