import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { LeadStatus } from "@shared/schema";

interface StatusBadgeProps {
  status: LeadStatus | string;
  size?: "sm" | "default";
}

export default function StatusBadge({ status, size = "default" }: StatusBadgeProps) {
  const getStatusStyles = () => {
    switch (status) {
      case "hot":
        return "bg-red-100 text-red-800 hover:bg-red-100";
      case "warm":
        return "bg-yellow-100 text-yellow-800 hover:bg-yellow-100";
      case "cold":
        return "bg-blue-100 text-blue-800 hover:bg-blue-100";
      case "new":
        return "bg-gray-100 text-gray-800 hover:bg-gray-100";
      default:
        return "bg-gray-100 text-gray-800 hover:bg-gray-100";
    }
  };

  const getStatusText = () => {
    switch (status) {
      case "hot":
        return "Hot";
      case "warm":
        return "Warm";
      case "cold":
        return "Cold";
      case "new":
        return "New";
      default:
        return status.charAt(0).toUpperCase() + status.slice(1);
    }
  };

  return (
    <Badge
      variant="outline"
      className={cn(
        getStatusStyles(),
        size === "sm" ? "text-xs py-0 px-2" : "text-xs py-1 px-2"
      )}
    >
      {getStatusText()}
    </Badge>
  );
}
