import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";

interface LeadStatsProps {
  title: string;
  value: number;
  icon: React.ReactNode;
  iconBg: string;
  details?: string;
  className?: string;
}

export function LeadStats({
  title,
  value,
  icon,
  iconBg,
  details,
  className,
}: LeadStatsProps) {
  return (
    <Card className={cn("overflow-hidden", className)}>
      <CardContent className="p-6">
        <div className="flex justify-between items-start">
          <div>
            <p className="text-sm font-medium text-gray-500 truncate">{title}</p>
            <p className="text-3xl font-semibold mt-1">{value}</p>
          </div>
          <div className={cn("h-10 w-10 rounded-full flex items-center justify-center", iconBg)}>
            {icon}
          </div>
        </div>
        {details && (
          <div className="mt-4 flex items-center text-sm text-gray-500">
            <span>{details}</span>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
