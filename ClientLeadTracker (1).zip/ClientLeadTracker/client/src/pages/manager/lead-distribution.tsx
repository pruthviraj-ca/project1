import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Sidebar } from "@/components/nav/sidebar";
import { Header } from "@/components/nav/header";
import { ShareIcon, UsersIcon } from "lucide-react";
import { Lead } from "@shared/schema";

interface EmployeeWithLeads {
  id: number;
  name: string;
  email: string;
  leadCount: number;
  selected: boolean;
}

export default function LeadDistribution() {
  const [location, navigate] = useLocation();
  const { toast } = useToast();
  const [distributionMethod, setDistributionMethod] = useState<string>("equal");
  const [leadSource, setLeadSource] = useState<string>("all");
  const [employees, setEmployees] = useState<EmployeeWithLeads[]>([]);
  const [selectedCount, setSelectedCount] = useState<number>(0);
  const [leadsPerEmployee, setLeadsPerEmployee] = useState<number>(0);

  // Fetch employees
  const { data: employeesData, isLoading: isLoadingEmployees } = useQuery({
    queryKey: ["/api/employees"],
  });

  // Fetch unassigned clients
  const { data: unassignedClients, isLoading: isLoadingClients } = useQuery({
    queryKey: ["/api/clients/unassigned"],
  });

  // Calculate the number of leads per employee
  useEffect(() => {
    if (unassignedClients && employees) {
      const selectedEmployeeCount = employees.filter(emp => emp.selected).length;
      if (selectedEmployeeCount > 0) {
        setSelectedCount(selectedEmployeeCount);
        setLeadsPerEmployee(Math.floor(unassignedClients.length / selectedEmployeeCount));
      } else {
        setSelectedCount(0);
        setLeadsPerEmployee(0);
      }
    }
  }, [unassignedClients, employees]);

  // Initialize employees data when loaded
  useEffect(() => {
    if (employeesData) {
      setEmployees(
        employeesData.map((emp: any) => ({
          id: emp.id,
          name: emp.name,
          email: emp.email,
          leadCount: emp.assignedLeads || 0,
          selected: true,
        }))
      );
    }
  }, [employeesData]);

  // Toggle employee selection
  const toggleEmployeeSelection = (empId: number) => {
    setEmployees(
      employees.map(emp => 
        emp.id === empId ? { ...emp, selected: !emp.selected } : emp
      )
    );
  };

  // Distribute leads mutation
  const distributeMutation = useMutation({
    mutationFn: async (data: { employeeIds: number[], distributionMethod: string }) => {
      const res = await apiRequest("POST", "/api/clients/distribute", data);
      return await res.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Leads distributed",
        description: data.message,
      });
      
      // Invalidate queries to refresh data
      queryClient.invalidateQueries({ queryKey: ["/api/clients/unassigned"] });
      queryClient.invalidateQueries({ queryKey: ["/api/employees"] });
      
      // Navigate back to dashboard
      navigate("/manager");
    },
    onError: (error: Error) => {
      toast({
        title: "Distribution failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Handle distribution
  const handleDistributeLeads = () => {
    const selectedEmployeeIds = employees
      .filter(emp => emp.selected)
      .map(emp => emp.id);
    
    if (selectedEmployeeIds.length === 0) {
      toast({
        title: "No employees selected",
        description: "Please select at least one employee to distribute leads.",
        variant: "destructive",
      });
      return;
    }
    
    if (!unassignedClients || unassignedClients.length === 0) {
      toast({
        title: "No leads to distribute",
        description: "There are no unassigned leads to distribute.",
        variant: "destructive",
      });
      return;
    }
    
    distributeMutation.mutate({
      employeeIds: selectedEmployeeIds,
      distributionMethod,
    });
  };

  return (
    <div className="min-h-screen bg-gray-100 flex">
      <Sidebar />
      
      <div className="flex-1 flex flex-col">
        <Header title="Lead Distribution" />
        
        <main className="flex-1 p-6">
          <Card className="mb-6">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <ShareIcon className="h-5 w-5 text-primary" />
                <span>Lead Distribution</span>
              </CardTitle>
              <CardDescription>
                Assign unassigned leads to your team members
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 gap-y-6 gap-x-4 sm:grid-cols-6">
                <div className="sm:col-span-3">
                  <Label htmlFor="lead-source">Lead Source</Label>
                  <Select
                    value={leadSource}
                    onValueChange={setLeadSource}
                  >
                    <SelectTrigger id="lead-source" className="mt-1">
                      <SelectValue placeholder="Select lead source" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">
                        All Unassigned Leads ({isLoadingClients ? "..." : unassignedClients?.length || 0})
                      </SelectItem>
                      <SelectItem value="recent">
                        Recent Upload ({isLoadingClients ? "..." : unassignedClients?.length || 0})
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="sm:col-span-3">
                  <Label htmlFor="distribution-method">Distribution Method</Label>
                  <Select
                    value={distributionMethod}
                    onValueChange={setDistributionMethod}
                  >
                    <SelectTrigger id="distribution-method" className="mt-1">
                      <SelectValue placeholder="Select distribution method" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="equal">Distribute Equally</SelectItem>
                      <SelectItem value="manual">Manual Distribution</SelectItem>
                      <SelectItem value="performance">Distribute by Performance</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="mt-6">
                <h4 className="text-sm font-medium text-gray-700 mb-2">Select Employees</h4>
                {isLoadingEmployees ? (
                  <p>Loading employees...</p>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
                    {employees.map((employee) => (
                      <div key={employee.id} className="relative">
                        <div className="flex items-start">
                          <div className="flex items-center h-5">
                            <Checkbox
                              id={`employee-${employee.id}`}
                              checked={employee.selected}
                              onCheckedChange={() => toggleEmployeeSelection(employee.id)}
                            />
                          </div>
                          <div className="ml-3 text-sm">
                            <Label
                              htmlFor={`employee-${employee.id}`}
                              className="font-medium text-gray-700"
                            >
                              {employee.name}
                            </Label>
                            <p className="text-gray-500">{employee.leadCount} leads</p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="mt-6 flex items-center">
                <Button
                  onClick={handleDistributeLeads}
                  disabled={distributeMutation.isPending || selectedCount === 0 || (unassignedClients?.length || 0) === 0}
                  className="flex items-center gap-2"
                >
                  <ShareIcon className="h-4 w-4" />
                  <span>
                    {distributeMutation.isPending ? "Distributing..." : "Distribute Leads"}
                  </span>
                </Button>
                <span className="ml-4 text-sm text-gray-500">
                  {selectedCount > 0 && unassignedClients && unassignedClients.length > 0
                    ? `This will assign approximately ${leadsPerEmployee} leads to each selected employee.`
                    : "Select employees and make sure there are unassigned leads."}
                </span>
              </div>
            </CardContent>
          </Card>
        </main>
      </div>
    </div>
  );
}
