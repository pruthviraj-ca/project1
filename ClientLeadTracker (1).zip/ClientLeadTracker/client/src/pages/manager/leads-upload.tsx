import { useState, useEffect } from "react";
import { useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Sidebar } from "@/components/nav/sidebar";
import { Header } from "@/components/nav/header";
import { Users, Building, Upload, FileText, AlertCircle, Download } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

export default function LeadsUpload() {
  const [location, navigate] = useLocation();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState<string>("clients");
  const [clientFile, setClientFile] = useState<File | null>(null);
  const [propertyFile, setPropertyFile] = useState<File | null>(null);
  const [clientXmlData, setClientXmlData] = useState<string>("");
  const [propertyXmlData, setPropertyXmlData] = useState<string>("");
  const [clientDragActive, setClientDragActive] = useState<boolean>(false);
  const [propertyDragActive, setPropertyDragActive] = useState<boolean>(false);
  
  // Load default XML files on mount
  useEffect(() => {
    // Load default client leads XML
    fetch('/client_leads.xml')
      .then(response => response.text())
      .then(xmlData => {
        setClientXmlData(xmlData);
        // Create a virtual file for UI display
        const file = new File([xmlData], "client_leads.xml", { type: "text/xml" });
        setClientFile(file);
      })
      .catch(error => {
        console.error("Error loading client leads XML:", error);
      });
    
    // Load default property inventory XML
    fetch('/flat_inventory.xml')
      .then(response => response.text())
      .then(xmlData => {
        setPropertyXmlData(xmlData);
        // Create a virtual file for UI display
        const file = new File([xmlData], "flat_inventory.xml", { type: "text/xml" });
        setPropertyFile(file);
      })
      .catch(error => {
        console.error("Error loading property inventory XML:", error);
      });
  }, []);

  // Client XML upload mutation
  const uploadClientMutation = useMutation({
    mutationFn: async (xmlData: string) => {
      const res = await apiRequest("POST", "/api/clients/upload", { xmlData });
      return await res.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Client leads uploaded",
        description: data.message,
      });
      setClientFile(null);
      setClientXmlData("");
    },
    onError: (error: Error) => {
      toast({
        title: "Upload failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Property XML upload mutation
  const uploadPropertyMutation = useMutation({
    mutationFn: async (xmlData: string) => {
      const res = await apiRequest("POST", "/api/properties/upload", { xmlData });
      return await res.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Property data uploaded",
        description: data.message,
      });
      setPropertyFile(null);
      setPropertyXmlData("");
    },
    onError: (error: Error) => {
      toast({
        title: "Upload failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Handle client file selection
  const handleClientFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setClientFile(file);
      
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target && typeof event.target.result === "string") {
          setClientXmlData(event.target.result);
        }
      };
      reader.readAsText(file);
    }
  };

  // Handle property file selection
  const handlePropertyFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setPropertyFile(file);
      
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target && typeof event.target.result === "string") {
          setPropertyXmlData(event.target.result);
        }
      };
      reader.readAsText(file);
    }
  };

  // Handle client XML upload
  const handleClientUpload = () => {
    if (!clientXmlData) {
      toast({
        title: "No file selected",
        description: "Please select an XML file to upload",
        variant: "destructive",
      });
      return;
    }
    uploadClientMutation.mutate(clientXmlData);
  };

  // Handle property XML upload
  const handlePropertyUpload = () => {
    if (!propertyXmlData) {
      toast({
        title: "No file selected",
        description: "Please select an XML file to upload",
        variant: "destructive",
      });
      return;
    }
    uploadPropertyMutation.mutate(propertyXmlData);
  };

  // Handle dragover for client dropzone
  const handleClientDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setClientDragActive(true);
  };

  // Handle dragleave for client dropzone
  const handleClientDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setClientDragActive(false);
  };

  // Handle drop for client dropzone
  const handleClientDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setClientDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      setClientFile(file);
      
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target && typeof event.target.result === "string") {
          setClientXmlData(event.target.result);
        }
      };
      reader.readAsText(file);
    }
  };

  // Handle dragover for property dropzone
  const handlePropertyDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setPropertyDragActive(true);
  };

  // Handle dragleave for property dropzone
  const handlePropertyDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setPropertyDragActive(false);
  };

  // Handle drop for property dropzone
  const handlePropertyDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setPropertyDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      setPropertyFile(file);
      
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target && typeof event.target.result === "string") {
          setPropertyXmlData(event.target.result);
        }
      };
      reader.readAsText(file);
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 flex">
      <Sidebar />
      
      <div className="flex-1 flex flex-col">
        <Header title="Upload Data" />
        
        <main className="flex-1 p-6">
          <Card className="max-w-3xl mx-auto">
            <CardHeader>
              <div className="flex items-center gap-2">
                <Upload className="h-5 w-5 text-primary" />
                <CardTitle>Upload Data</CardTitle>
              </div>
              <CardDescription>
                Upload client leads and property data in XML format
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                <TabsList className="grid w-full grid-cols-2 mb-6">
                  <TabsTrigger value="clients" className="flex items-center gap-2">
                    <Users className="h-4 w-4" />
                    <span>Client Leads</span>
                  </TabsTrigger>
                  <TabsTrigger value="properties" className="flex items-center gap-2">
                    <Building className="h-4 w-4" />
                    <span>Property Data</span>
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="clients">
                  <Alert className="mb-6">
                    <AlertCircle className="h-4 w-4" />
                    <AlertTitle>Client Lead Format</AlertTitle>
                    <AlertDescription>
                      The XML file should include client information with Client Unique ID, Client Name, 
                      Phone Number, Email ID, and Time of Inquiry.
                    </AlertDescription>
                  </Alert>
                  
                  <div 
                    className={`max-w-lg mx-auto flex justify-center px-6 pt-5 pb-6 border-2 ${
                      clientDragActive ? 'border-primary border-dashed bg-primary/5' : 'border-gray-300 border-dashed'
                    } rounded-md`}
                    onDragOver={handleClientDragOver}
                    onDragLeave={handleClientDragLeave}
                    onDrop={handleClientDrop}
                  >
                    <div className="space-y-1 text-center">
                      <FileText className="mx-auto h-12 w-12 text-gray-400" />
                      <div className="flex text-sm text-gray-600">
                        <label htmlFor="client-file-upload" className="relative cursor-pointer bg-white rounded-md font-medium text-primary hover:text-primary-dark focus-within:outline-none">
                          <span>Upload a file</span>
                          <Input 
                            id="client-file-upload" 
                            name="client-file-upload" 
                            type="file" 
                            accept=".xml" 
                            className="sr-only"
                            onChange={handleClientFileChange}
                          />
                        </label>
                        <p className="pl-1">or drag and drop</p>
                      </div>
                      <p className="text-xs text-gray-500">XML up to 10MB</p>
                      
                      {clientFile && (
                        <div className="mt-3 text-sm text-primary">
                          <p>Selected file: {clientFile.name}</p>
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="flex justify-end mt-6">
                    <Button 
                      onClick={handleClientUpload} 
                      disabled={!clientXmlData || uploadClientMutation.isPending}
                      className="flex items-center gap-2"
                    >
                      {uploadClientMutation.isPending ? (
                        <>Uploading...</>
                      ) : (
                        <>
                          <Upload className="h-4 w-4" />
                          <span>Upload Client Leads</span>
                        </>
                      )}
                    </Button>
                  </div>
                </TabsContent>

                <TabsContent value="properties">
                  <Alert className="mb-6">
                    <AlertCircle className="h-4 w-4" />
                    <AlertTitle>Property Data Format</AlertTitle>
                    <AlertDescription>
                      The XML file should include property information with Flat Unique ID, Flat Type (2BHK / 3BHK),
                      Builder Name, Flat Number, and Address.
                    </AlertDescription>
                  </Alert>
                  
                  <div 
                    className={`max-w-lg mx-auto flex justify-center px-6 pt-5 pb-6 border-2 ${
                      propertyDragActive ? 'border-primary border-dashed bg-primary/5' : 'border-gray-300 border-dashed'
                    } rounded-md`}
                    onDragOver={handlePropertyDragOver}
                    onDragLeave={handlePropertyDragLeave}
                    onDrop={handlePropertyDrop}
                  >
                    <div className="space-y-1 text-center">
                      <FileText className="mx-auto h-12 w-12 text-gray-400" />
                      <div className="flex text-sm text-gray-600">
                        <label htmlFor="property-file-upload" className="relative cursor-pointer bg-white rounded-md font-medium text-primary hover:text-primary-dark focus-within:outline-none">
                          <span>Upload a file</span>
                          <Input 
                            id="property-file-upload" 
                            name="property-file-upload" 
                            type="file" 
                            accept=".xml" 
                            className="sr-only"
                            onChange={handlePropertyFileChange}
                          />
                        </label>
                        <p className="pl-1">or drag and drop</p>
                      </div>
                      <p className="text-xs text-gray-500">XML up to 10MB</p>
                      
                      {propertyFile && (
                        <div className="mt-3 text-sm text-primary">
                          <p>Selected file: {propertyFile.name}</p>
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="flex justify-end mt-6">
                    <Button 
                      onClick={handlePropertyUpload} 
                      disabled={!propertyXmlData || uploadPropertyMutation.isPending}
                      className="flex items-center gap-2"
                    >
                      {uploadPropertyMutation.isPending ? (
                        <>Uploading...</>
                      ) : (
                        <>
                          <Upload className="h-4 w-4" />
                          <span>Upload Property Data</span>
                        </>
                      )}
                    </Button>
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button variant="outline" onClick={() => navigate("/manager")}>
                Cancel
              </Button>
              <Button 
                onClick={() => navigate("/manager/distribute")} 
                disabled={(activeTab === "clients" && uploadClientMutation.isPending) || 
                  (activeTab === "properties" && uploadPropertyMutation.isPending)}
              >
                Next: Distribute Leads
              </Button>
            </CardFooter>
          </Card>
        </main>
      </div>
    </div>
  );
}
