import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell,
} from "recharts";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Upload,
  Users,
  HomeIcon,
  Building,
  BarChartIcon,
  CheckCircle,
  UserCheck,
  AlertCircle,
} from "lucide-react";
import { Sidebar } from "@/components/nav/sidebar";
import { Header } from "@/components/nav/header";
import StatusBadge from "@/components/leads/status-badge";
import LeadStatusChart from "@/components/charts/lead-status-chart";

export default function ManagerDashboard() {
  const { user } = useAuth();
  const [location, navigate] = useLocation();

  // Fetch data for the dashboard
  const { data: clientStats, isLoading: isLoadingClientStats } = useQuery({
    queryKey: ["/api/stats/clients"],
  });

  const { data: propertyStats, isLoading: isLoadingPropertyStats } = useQuery({
    queryKey: ["/api/stats/properties"],
  });

  const { data: employees, isLoading: isLoadingEmployees } = useQuery({
    queryKey: ["/api/employees"],
  });

  const { data: employeePerformance, isLoading: isLoadingPerformance } = useQuery({
    queryKey: ["/api/stats/employee-performance"],
  });

  const { data: missedFollowUps, isLoading: isLoadingMissedFollowUps } = useQuery({
    queryKey: ["/api/stats/missed-followups"],
  });
  
  // Format property stats for chart
  const formatPropertyStats = () => {
    if (!propertyStats) return [];
    return Object.entries(propertyStats).map(([type, count]) => ({
      name: type,
      value: count,
    }));
  };

  // Calculate online employees (this would be more dynamic in a real app)
  const onlineEmployeesCount = employees?.length > 0 ? Math.ceil(employees.length * 0.6) : 0;

  // Get this month's settlements
  const thisMonthSettlements = employeePerformance
    ? employeePerformance.reduce((sum, emp) => sum + emp.settlements, 0)
    : 0;

  return (
    <div className="min-h-screen bg-gray-100 flex">
      <Sidebar />
      
      <div className="flex-1 flex flex-col">
        <Header title="Manager Dashboard" />
        
        <main className="flex-1 p-6">
          {/* Action Buttons */}
          <div className="flex justify-end mb-6 gap-3">
            <Button onClick={() => navigate("/manager/upload")} className="gap-2">
              <Upload size={16} />
              <span>Upload Leads/Properties</span>
            </Button>
            <Button onClick={() => navigate("/manager/distribute")} className="gap-2" variant="secondary">
              <Users size={16} />
              <span>Distribute Leads</span>
            </Button>
          </div>
          
          {/* Overview Stats */}
          <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4 mb-6">
            {/* Total Leads */}
            <Card>
              <CardContent className="p-6">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="text-sm font-medium text-gray-500">Total Leads</p>
                    <p className="text-3xl font-semibold mt-1">
                      {isLoadingClientStats ? "..." : clientStats?.total || 0}
                    </p>
                  </div>
                  <div className="h-10 w-10 bg-blue-100 rounded-full flex items-center justify-center">
                    <Users className="h-5 w-5 text-blue-600" />
                  </div>
                </div>
                <div className="mt-4 flex justify-between items-center text-sm">
                  <span className="text-gray-500">
                    Unassigned: {isLoadingClientStats ? "..." : (clientStats?.new || 0)}
                  </span>
                  <Link to="/manager/distribute" className="text-primary font-medium hover:underline">
                    View all
                  </Link>
                </div>
              </CardContent>
            </Card>

            {/* Available Properties */}
            <Card>
              <CardContent className="p-6">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="text-sm font-medium text-gray-500">Available Properties</p>
                    <p className="text-3xl font-semibold mt-1">
                      {isLoadingPropertyStats ? "..." : 
                        Object.values(propertyStats || {}).reduce((sum, count) => sum + (count as number), 0)}
                    </p>
                  </div>
                  <div className="h-10 w-10 bg-green-100 rounded-full flex items-center justify-center">
                    <Building className="h-5 w-5 text-green-600" />
                  </div>
                </div>
                <div className="mt-4 flex justify-between items-center text-sm">
                  <span className="text-gray-500">
                    {isLoadingPropertyStats ? "..." : 
                      Object.entries(propertyStats || {})
                        .map(([type, count]) => `${type}: ${count}`)
                        .join(" | ")
                    }
                  </span>
                  <Link to="#" className="text-primary font-medium hover:underline">
                    View all
                  </Link>
                </div>
              </CardContent>
            </Card>

            {/* Active Employees */}
            <Card>
              <CardContent className="p-6">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="text-sm font-medium text-gray-500">Active Employees</p>
                    <p className="text-3xl font-semibold mt-1">
                      {isLoadingEmployees ? "..." : employees?.length || 0}
                    </p>
                  </div>
                  <div className="h-10 w-10 bg-purple-100 rounded-full flex items-center justify-center">
                    <UserCheck className="h-5 w-5 text-purple-600" />
                  </div>
                </div>
                <div className="mt-4 flex justify-between items-center text-sm">
                  <span className="text-gray-500">
                    Online now: {onlineEmployeesCount}
                  </span>
                  <Link to="#" className="text-primary font-medium hover:underline">
                    View all
                  </Link>
                </div>
              </CardContent>
            </Card>

            {/* Settlements */}
            <Card>
              <CardContent className="p-6">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="text-sm font-medium text-gray-500">Settlements (This Month)</p>
                    <p className="text-3xl font-semibold mt-1">
                      {isLoadingPerformance ? "..." : thisMonthSettlements}
                    </p>
                  </div>
                  <div className="h-10 w-10 bg-yellow-100 rounded-full flex items-center justify-center">
                    <CheckCircle className="h-5 w-5 text-yellow-600" />
                  </div>
                </div>
                <div className="mt-4 flex justify-between items-center text-sm">
                  <span className="text-gray-500">
                    Revenue: ₹{(thisMonthSettlements * 0.2).toFixed(1)}M
                  </span>
                  <Link to="#" className="text-primary font-medium hover:underline">
                    View all
                  </Link>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Lead Status and Follow-ups */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-5 mb-6">
            {/* Lead Status Chart */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">Lead Status</CardTitle>
              </CardHeader>
              <CardContent>
                {isLoadingClientStats ? (
                  <div className="h-48 flex items-center justify-center">
                    <p>Loading chart data...</p>
                  </div>
                ) : (
                  <LeadStatusChart 
                    hot={clientStats?.hot || 0} 
                    warm={clientStats?.warm || 0} 
                    cold={clientStats?.cold || 0} 
                    total={(clientStats?.total || 0) - (clientStats?.new || 0)}
                  />
                )}
              </CardContent>
            </Card>

            {/* Upcoming Follow-ups */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">Upcoming Follow-ups</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {isLoadingPerformance ? (
                    <p>Loading follow-ups...</p>
                  ) : (
                    <>
                      {employeePerformance?.slice(0, 3).map((employee) => (
                        <div key={employee.id} className="flex items-start">
                          <div className="flex-shrink-0 h-10 w-10 rounded-full bg-gray-300 flex items-center justify-center">
                            <span className="text-xs font-medium text-gray-600">
                              {employee.name.split(' ').map(n => n[0]).join('')}
                            </span>
                          </div>
                          <div className="ml-3">
                            <p className="text-sm font-medium text-gray-900">{employee.name}</p>
                            <p className="text-xs text-gray-500">
                              {employee.upcomingMeetings} upcoming meetings
                            </p>
                          </div>
                        </div>
                      ))}
                      <Link to="#" className="block text-sm text-center font-medium text-primary pt-2">
                        View all follow-ups
                      </Link>
                    </>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Missed Follow-ups Alert */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">Missed Follow-ups</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {isLoadingMissedFollowUps ? (
                    <p>Loading missed follow-ups...</p>
                  ) : missedFollowUps?.length === 0 ? (
                    <p className="text-sm text-gray-500">No missed follow-ups</p>
                  ) : (
                    <>
                      {employeePerformance?.filter(emp => emp.missedFollowUps > 0).slice(0, 3).map((employee) => (
                        <div key={employee.id} className="flex items-start bg-red-50 p-2 rounded-md">
                          <div className="flex-shrink-0 h-10 w-10 rounded-full bg-red-100 flex items-center justify-center">
                            <span className="text-xs font-medium text-red-600">
                              {employee.name.split(' ').map(n => n[0]).join('')}
                            </span>
                          </div>
                          <div className="ml-3">
                            <p className="text-sm font-medium text-gray-900">
                              {employee.name} <span className="text-xs text-red-500">{employee.missedFollowUps} missed</span>
                            </p>
                            <p className="text-xs text-gray-500">Follow up required</p>
                          </div>
                        </div>
                      ))}
                      <Link to="#" className="block text-sm text-center font-medium text-primary pt-2">
                        View all missed follow-ups
                      </Link>
                    </>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Employee Performance Table */}
          <Card className="mb-6">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-lg">Employee Performance</CardTitle>
              <Button size="sm" className="gap-1">
                <Users size={16} />
                <span>Manage Team</span>
              </Button>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-gray-200">
                      <th className="text-left p-3 text-xs font-medium text-gray-500 uppercase tracking-wider">Employee</th>
                      <th className="text-left p-3 text-xs font-medium text-gray-500 uppercase tracking-wider">Assigned Leads</th>
                      <th className="text-left p-3 text-xs font-medium text-gray-500 uppercase tracking-wider">Hot Leads</th>
                      <th className="text-left p-3 text-xs font-medium text-gray-500 uppercase tracking-wider">Upcoming Meetings</th>
                      <th className="text-left p-3 text-xs font-medium text-gray-500 uppercase tracking-wider">Missed Follow-ups</th>
                      <th className="text-left p-3 text-xs font-medium text-gray-500 uppercase tracking-wider">Settlements</th>
                      <th className="text-left p-3 text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                    {isLoadingPerformance ? (
                      <tr>
                        <td colSpan={7} className="p-4 text-center">Loading employee data...</td>
                      </tr>
                    ) : employeePerformance?.length === 0 ? (
                      <tr>
                        <td colSpan={7} className="p-4 text-center">No employees found</td>
                      </tr>
                    ) : (
                      employeePerformance?.map((employee) => (
                        <tr key={employee.id}>
                          <td className="p-3 whitespace-nowrap">
                            <div className="flex items-center">
                              <div className="flex-shrink-0 h-10 w-10 rounded-full bg-gray-300 flex items-center justify-center">
                                <span className="text-xs font-medium text-gray-600">
                                  {employee.name.split(' ').map(n => n[0]).join('')}
                                </span>
                              </div>
                              <div className="ml-4">
                                <div className="text-sm font-medium text-gray-900">{employee.name}</div>
                                <div className="text-sm text-gray-500">{employee.email}</div>
                              </div>
                            </div>
                          </td>
                          <td className="p-3 whitespace-nowrap text-sm text-gray-900">
                            {employee.assignedLeads}
                          </td>
                          <td className="p-3 whitespace-nowrap">
                            <div className="text-sm text-gray-900">{employee.leadDistribution.hot}</div>
                            <div className="text-xs text-gray-500">
                              {employee.assignedLeads > 0 
                                ? `${Math.round((employee.leadDistribution.hot / employee.assignedLeads) * 100)}%`
                                : '0%'}
                            </div>
                          </td>
                          <td className="p-3 whitespace-nowrap text-sm text-gray-900">
                            {employee.upcomingMeetings}
                          </td>
                          <td className="p-3 whitespace-nowrap">
                            <div className={`text-sm ${employee.missedFollowUps > 0 ? 'text-red-600 font-medium' : 'text-gray-900'}`}>
                              {employee.missedFollowUps}
                            </div>
                          </td>
                          <td className="p-3 whitespace-nowrap text-sm text-gray-900">
                            {employee.settlements}
                          </td>
                          <td className="p-3 whitespace-nowrap text-sm">
                            <Button variant="link" size="sm" className="p-0">View</Button>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </main>
      </div>
    </div>
  );
}
