import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { useAuth } from "@/hooks/use-auth";
import { insertUserSchema, loginSchema } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Checkbox } from "@/components/ui/checkbox";
import { Building as BuildingIcon, User as UserIcon } from "lucide-react";

const loginFormSchema = loginSchema;

const registerFormSchema = insertUserSchema.extend({
  confirmPassword: z.string().min(1, "Confirm Password is required"),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"],
});

export default function AuthPage() {
  const [location, navigate] = useLocation();
  const { user, loginMutation, registerMutation } = useAuth();
  const [activeTab, setActiveTab] = useState<string>("login");

  // Initialize login form
  const loginForm = useForm<z.infer<typeof loginFormSchema>>({
    resolver: zodResolver(loginFormSchema),
    defaultValues: {
      username: "",
      password: "",
    },
  });

  // Initialize register form
  const registerForm = useForm<z.infer<typeof registerFormSchema>>({
    resolver: zodResolver(registerFormSchema),
    defaultValues: {
      username: "",
      password: "",
      confirmPassword: "",
      email: "",
      name: "",
      role: "employee",
    },
  });

  const onLoginSubmit = async (data: z.infer<typeof loginFormSchema>) => {
    loginMutation.mutate(data, {
      onSuccess: () => {
        // Redirect based on user role
        const user = loginMutation.data;
        if (user && user.role === "manager") {
          navigate("/manager");
        } else if (user) {
          navigate("/employee");
        }
      },
    });
  };

  const onRegisterSubmit = async (data: z.infer<typeof registerFormSchema>) => {
    // Remove confirmPassword as it's not in the API schema
    const { confirmPassword, ...registerData } = data;
    
    registerMutation.mutate(registerData, {
      onSuccess: () => {
        // Redirect based on user role
        const user = registerMutation.data;
        if (user && user.role === "manager") {
          navigate("/manager");
        } else if (user) {
          navigate("/employee");
        }
      },
    });
  };

  // Redirect if already logged in
  useEffect(() => {
    if (user) {
      if (user.role === "manager") {
        navigate("/manager");
      } else {
        navigate("/employee");
      }
    }
  }, [user, navigate]);

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-gray-100">
      <div className="w-full max-w-5xl flex flex-col lg:flex-row overflow-hidden bg-white rounded-lg shadow-lg">
        {/* Left Side - Form */}
        <div className="w-full lg:w-1/2 p-6">
          <div className="mb-8 text-center">
            <h1 className="text-2xl font-bold text-gray-800">PropertySmart CRM</h1>
            <p className="text-gray-600">Sign in to your account</p>
          </div>

          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-2 mb-6">
              <TabsTrigger value="login">Login</TabsTrigger>
              <TabsTrigger value="register">Register</TabsTrigger>
            </TabsList>

            <TabsContent value="login">
              <Form {...loginForm}>
                <form onSubmit={loginForm.handleSubmit(onLoginSubmit)} className="space-y-4">
                  <FormField
                    control={loginForm.control}
                    name="username"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Username</FormLabel>
                        <FormControl>
                          <Input placeholder="Enter your username" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={loginForm.control}
                    name="password"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Password</FormLabel>
                        <FormControl>
                          <Input type="password" placeholder="Enter your password" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Checkbox id="remember-me" />
                      <label htmlFor="remember-me" className="text-sm text-gray-700">
                        Remember me
                      </label>
                    </div>
                    <a href="#" className="text-sm font-medium text-primary hover:text-primary-dark">
                      Forgot password?
                    </a>
                  </div>

                  <Button 
                    type="submit" 
                    className="w-full"
                    disabled={loginMutation.isPending}
                  >
                    {loginMutation.isPending ? "Signing in..." : "Sign In"}
                  </Button>
                </form>
              </Form>
            </TabsContent>

            <TabsContent value="register">
              <Form {...registerForm}>
                <form onSubmit={registerForm.handleSubmit(onRegisterSubmit)} className="space-y-4">
                  <FormField
                    control={registerForm.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Full Name</FormLabel>
                        <FormControl>
                          <Input placeholder="Enter your full name" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={registerForm.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Email</FormLabel>
                        <FormControl>
                          <Input type="email" placeholder="Enter your email" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={registerForm.control}
                    name="username"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Username</FormLabel>
                        <FormControl>
                          <Input placeholder="Choose a username" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={registerForm.control}
                      name="password"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Password</FormLabel>
                          <FormControl>
                            <Input type="password" placeholder="Create a password" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={registerForm.control}
                      name="confirmPassword"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Confirm Password</FormLabel>
                          <FormControl>
                            <Input type="password" placeholder="Confirm your password" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={registerForm.control}
                    name="role"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Role</FormLabel>
                        <div className="flex space-x-4 mt-1">
                          <div
                            className={`flex-1 p-3 border rounded-md flex flex-col items-center cursor-pointer transition-colors ${
                              field.value === 'employee' ? 'border-primary bg-primary/5' : 'border-gray-200'
                            }`}
                            onClick={() => field.onChange('employee')}
                          >
                            <UserIcon className={field.value === 'employee' ? 'text-primary' : 'text-gray-400'} />
                            <span className={`mt-2 text-sm font-medium ${field.value === 'employee' ? 'text-primary' : 'text-gray-500'}`}>
                              Employee
                            </span>
                          </div>
                          <div
                            className={`flex-1 p-3 border rounded-md flex flex-col items-center cursor-pointer transition-colors ${
                              field.value === 'manager' ? 'border-primary bg-primary/5' : 'border-gray-200'
                            }`}
                            onClick={() => field.onChange('manager')}
                          >
                            <BuildingIcon className={field.value === 'manager' ? 'text-primary' : 'text-gray-400'} />
                            <span className={`mt-2 text-sm font-medium ${field.value === 'manager' ? 'text-primary' : 'text-gray-500'}`}>
                              Manager
                            </span>
                          </div>
                        </div>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <Button 
                    type="submit" 
                    className="w-full"
                    disabled={registerMutation.isPending}
                  >
                    {registerMutation.isPending ? "Creating Account..." : "Create Account"}
                  </Button>
                </form>
              </Form>
            </TabsContent>
          </Tabs>
        </div>

        {/* Right Side - Hero */}
        <div className="w-full lg:w-1/2 bg-primary p-8 text-white flex flex-col justify-center">
          <div className="max-w-md mx-auto">
            <h2 className="text-3xl font-bold mb-6">Real Estate Lead Management System</h2>
            <p className="mb-8">
              A complete solution for real estate professionals to manage leads, track interactions, and close deals more efficiently.
            </p>
            
            <div className="space-y-4">
              <div className="flex items-start">
                <div className="h-8 w-8 rounded-full bg-white/20 flex items-center justify-center mr-4 flex-shrink-0">
                  <span className="text-xl">✓</span>
                </div>
                <div>
                  <h3 className="text-lg font-semibold">Lead Management</h3>
                  <p className="text-sm text-white/80">Upload and distribute client leads to your team.</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="h-8 w-8 rounded-full bg-white/20 flex items-center justify-center mr-4 flex-shrink-0">
                  <span className="text-xl">✓</span>
                </div>
                <div>
                  <h3 className="text-lg font-semibold">Follow-up Tracking</h3>
                  <p className="text-sm text-white/80">Schedule and monitor client follow-ups with email reminders.</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="h-8 w-8 rounded-full bg-white/20 flex items-center justify-center mr-4 flex-shrink-0">
                  <span className="text-xl">✓</span>
                </div>
                <div>
                  <h3 className="text-lg font-semibold">Performance Analytics</h3>
                  <p className="text-sm text-white/80">Track employee performance and settlement rates.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
