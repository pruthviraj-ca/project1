import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { format } from "date-fns";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Sidebar } from "@/components/nav/sidebar";
import { Header } from "@/components/nav/header";
import { LeadTable } from "@/components/leads/lead-table";
import { LeadStats } from "@/components/leads/lead-stats";
import StatusBadge from "@/components/leads/status-badge";
import {
  User,
  Phone,
  Calendar,
  Building,
  CheckSquare,
  Search,
  Clock,
  AlertTriangle,
  Eye,
} from "lucide-react";

export default function EmployeeDashboard() {
  const { user } = useAuth();
  const [location, navigate] = useLocation();
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [searchTerm, setSearchTerm] = useState<string>("");

  // Fetch my clients
  const { data: clients, isLoading: isLoadingClients } = useQuery({
    queryKey: ["/api/clients", { employeeId: user?.id }],
    enabled: !!user?.id,
  });

  // Fetch my follow-ups for today
  const { data: todayFollowUps, isLoading: isLoadingTodayFollowUps } = useQuery({
    queryKey: ["/api/employees", user?.id, "followups/today"],
    enabled: !!user?.id,
  });

  // Fetch my missed follow-ups
  const { data: missedFollowUps, isLoading: isLoadingMissedFollowUps } = useQuery({
    queryKey: ["/api/employees", user?.id, "followups/missed"],
    enabled: !!user?.id,
  });

  // Fetch my scheduled site visits
  const { data: siteVisits, isLoading: isLoadingSiteVisits } = useQuery({
    queryKey: ["/api/employees", user?.id, "sitevisits"],
    enabled: !!user?.id,
  });

  // Fetch my settlements
  const { data: settlements, isLoading: isLoadingSettlements } = useQuery({
    queryKey: ["/api/employees", user?.id, "settlements"],
    enabled: !!user?.id,
  });

  // Statistics calculations
  const getLeadsByStatus = (status: string) => {
    if (!clients) return 0;
    return clients.filter((client: any) => client.status === status).length;
  };

  const hotLeads = getLeadsByStatus("hot");
  const warmLeads = getLeadsByStatus("warm");
  const coldLeads = getLeadsByStatus("cold");
  const totalLeads = clients?.length || 0;

  const completedFollowUps = todayFollowUps?.filter((fu: any) => fu.completed).length || 0;
  const remainingFollowUps = (todayFollowUps?.length || 0) - completedFollowUps;
  
  const scheduledVisits = siteVisits?.filter((sv: any) => !sv.completed).length || 0;
  const settlementsCount = settlements?.length || 0;

  // Filter clients based on search and status
  const filteredClients = clients?.filter((client: any) => {
    const matchesSearch = searchTerm === "" || 
      client.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      client.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      client.phone.includes(searchTerm);
      
    const matchesStatus = statusFilter === "all" || client.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="min-h-screen bg-gray-100 flex">
      <Sidebar />
      
      <div className="flex-1 flex flex-col">
        <Header title="My Dashboard" />
        
        <main className="flex-1 p-6">
          {/* Overview Stats */}
          <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4 mb-6">
            {/* My Leads */}
            <LeadStats
              title="My Leads"
              value={totalLeads}
              icon={<User className="h-5 w-5 text-blue-600" />}
              iconBg="bg-blue-100"
              details={`Hot: ${hotLeads} | Warm: ${warmLeads} | Cold: ${coldLeads}`}
            />

            {/* Follow-ups */}
            <LeadStats
              title="Today's Follow-ups"
              value={todayFollowUps?.length || 0}
              icon={<Calendar className="h-5 w-5 text-green-600" />}
              iconBg="bg-green-100"
              details={`Completed: ${completedFollowUps} | Remaining: ${remainingFollowUps}`}
            />

            {/* Site Visits */}
            <LeadStats
              title="Scheduled Site Visits"
              value={scheduledVisits}
              icon={<Building className="h-5 w-5 text-purple-600" />}
              iconBg="bg-purple-100"
              details="This Week"
            />

            {/* Settlements */}
            <LeadStats
              title="My Settlements"
              value={settlementsCount}
              icon={<CheckSquare className="h-5 w-5 text-yellow-600" />}
              iconBg="bg-yellow-100"
              details="This Month"
            />
          </div>

          {/* Today's Follow-ups & Missed Follow-ups */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            {/* Today's Follow-ups */}
            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-lg">Today's Follow-ups</CardTitle>
                <Link to="/employee/calendar" className="text-sm font-medium text-primary">
                  View all
                </Link>
              </CardHeader>
              <CardContent>
                {isLoadingTodayFollowUps ? (
                  <p>Loading follow-ups...</p>
                ) : todayFollowUps?.length === 0 ? (
                  <p className="text-gray-500">No follow-ups scheduled for today</p>
                ) : (
                  <ul className="divide-y divide-gray-200">
                    {todayFollowUps?.map((followUp: any) => (
                      <li key={followUp.id} className="py-4">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center">
                            <div className="flex-shrink-0">
                              <span className="inline-flex items-center justify-center h-10 w-10 rounded-full bg-blue-100">
                                <span className="font-medium text-blue-800">
                                  {followUp.clientName?.split(' ').map((n: string) => n[0]).join('')}
                                </span>
                              </span>
                            </div>
                            <div className="ml-4">
                              <div className="text-sm font-medium text-gray-900">{followUp.clientName}</div>
                              <div className="text-sm text-gray-500">{followUp.clientPhone}</div>
                              <div className="text-xs text-gray-500">
                                {followUp.scheduledTime ? format(new Date(followUp.scheduledTime), "h:mm a") : "No time set"}
                              </div>
                            </div>
                          </div>
                          <div className="flex">
                            <Button variant="success" size="sm" className="mr-2">
                              <Phone className="h-4 w-4 mr-1" /> Call
                            </Button>
                            <Button 
                              variant="outline" 
                              size="sm" 
                              onClick={() => navigate(`/employee/client/${followUp.clientId}`)}
                            >
                              <Eye className="h-4 w-4 mr-1" /> View
                            </Button>
                          </div>
                        </div>
                      </li>
                    ))}
                  </ul>
                )}
              </CardContent>
            </Card>

            {/* Missed Follow-ups */}
            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-lg flex items-center">
                  <AlertTriangle className="h-4 w-4 text-red-500 mr-2" />
                  Missed Follow-ups
                </CardTitle>
                <Link to="#" className="text-sm font-medium text-primary">
                  View all
                </Link>
              </CardHeader>
              <CardContent>
                {isLoadingMissedFollowUps ? (
                  <p>Loading missed follow-ups...</p>
                ) : missedFollowUps?.length === 0 ? (
                  <p className="text-gray-500">No missed follow-ups. Good job!</p>
                ) : (
                  <ul className="divide-y divide-gray-200">
                    {missedFollowUps?.map((followUp: any) => (
                      <li key={followUp.id} className="py-4 bg-red-50 px-3 rounded-md">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center">
                            <div className="flex-shrink-0">
                              <span className="inline-flex items-center justify-center h-10 w-10 rounded-full bg-red-100">
                                <span className="font-medium text-red-800">
                                  {followUp.clientName?.split(' ').map((n: string) => n[0]).join('')}
                                </span>
                              </span>
                            </div>
                            <div className="ml-4">
                              <div className="text-sm font-medium text-gray-900">{followUp.clientName}</div>
                              <div className="text-sm text-gray-500">{followUp.clientPhone}</div>
                              <div className="text-xs text-red-500">
                                Missed: {followUp.scheduledTime ? format(new Date(followUp.scheduledTime), "MMM d, h:mm a") : "Unknown time"}
                              </div>
                            </div>
                          </div>
                          <div className="flex">
                            <Button variant="destructive" size="sm" className="mr-2">
                              <Phone className="h-4 w-4 mr-1" /> Call Now
                            </Button>
                            <Button 
                              variant="outline" 
                              size="sm" 
                              onClick={() => navigate(`/employee/client/${followUp.clientId}`)}
                            >
                              <Calendar className="h-4 w-4 mr-1" /> Reschedule
                            </Button>
                          </div>
                        </div>
                      </li>
                    ))}
                  </ul>
                )}
              </CardContent>
            </Card>
          </div>

          {/* My Clients Tab/Table */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-lg">My Clients</CardTitle>
              <div className="flex items-center space-x-2">
                <div className="relative">
                  <Input
                    placeholder="Search clients..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-8"
                  />
                  <Search className="absolute left-2 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                </div>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-[150px]">
                    <SelectValue placeholder="All Leads" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Leads</SelectItem>
                    <SelectItem value="hot">Hot Leads</SelectItem>
                    <SelectItem value="warm">Warm Leads</SelectItem>
                    <SelectItem value="cold">Cold Leads</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardHeader>
            <CardContent>
              <LeadTable 
                clients={filteredClients || []} 
                isLoading={isLoadingClients} 
              />
            </CardContent>
          </Card>
        </main>
      </div>
    </div>
  );
}
