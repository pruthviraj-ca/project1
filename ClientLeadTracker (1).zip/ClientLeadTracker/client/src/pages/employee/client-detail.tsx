import { useState, useEffect } from "react";
import { useLocation, useParams } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { format } from "date-fns";
import { apiRequest, queryClient } from "@/lib/queryClient";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Sidebar } from "@/components/nav/sidebar";
import { Header } from "@/components/nav/header";
import { InteractionForm } from "@/components/forms/interaction-form";
import { FollowUpForm } from "@/components/forms/follow-up-form";
import StatusBadge from "@/components/leads/status-badge";
import {
  Phone,
  Mail,
  Calendar,
  ArrowLeft,
  User,
  Building,
  CheckCircle,
  Clock,
  X,
} from "lucide-react";

export default function ClientDetail() {
  const { id } = useParams();
  const clientId = parseInt(id);
  const { user } = useAuth();
  const [location, navigate] = useLocation();
  const [activeTab, setActiveTab] = useState("interactions");

  // Fetch client details
  const {
    data: client,
    isLoading: isLoadingClient,
    error: clientError,
  } = useQuery({
    queryKey: ["/api/clients", clientId],
    enabled: !!clientId,
  });

  // Fetch client interactions
  const {
    data: interactions,
    isLoading: isLoadingInteractions,
    error: interactionsError,
  } = useQuery({
    queryKey: ["/api/clients", clientId, "interactions"],
    enabled: !!clientId,
  });

  // Fetch client follow-ups
  const {
    data: followUps,
    isLoading: isLoadingFollowUps,
    error: followUpsError,
  } = useQuery({
    queryKey: ["/api/clients", clientId, "followups"],
    enabled: !!clientId,
  });

  // Fetch available properties
  const {
    data: properties,
    isLoading: isLoadingProperties,
    error: propertiesError,
  } = useQuery({
    queryKey: ["/api/properties/available"],
  });

  // Settlement mutation
  const settlementMutation = useMutation({
    mutationFn: async (data: { clientId: number; propertyId: number; employeeId: number }) => {
      const res = await apiRequest("POST", "/api/settlements", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/clients"] });
      queryClient.invalidateQueries({ queryKey: ["/api/properties/available"] });
      navigate("/employee");
    },
  });

  // Site visit mutation
  const siteVisitMutation = useMutation({
    mutationFn: async (data: {
      clientId: number;
      propertyId: number;
      employeeId: number;
      scheduledTime: string;
    }) => {
      const res = await apiRequest("POST", "/api/sitevisits", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/employees", user?.id, "sitevisits"] });
    },
  });

  // Sort interactions by date (newest first)
  const sortedInteractions = interactions
    ? [...interactions].sort(
        (a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
      )
    : [];

  // Find the next scheduled follow-up
  const nextFollowUp = followUps
    ? followUps
        .filter((fu) => !fu.completed && new Date(fu.scheduledTime) > new Date())
        .sort(
          (a, b) =>
            new Date(a.scheduledTime).getTime() - new Date(b.scheduledTime).getTime()
        )[0]
    : null;

  // Handle booking a site visit
  const handleBookSiteVisit = (propertyId: number) => {
    const now = new Date();
    now.setHours(now.getHours() + 24); // Schedule for tomorrow
    
    if (user && client) {
      siteVisitMutation.mutate({
        clientId: client.id,
        propertyId,
        employeeId: user.id,
        scheduledTime: now.toISOString(),
      });
    }
  };

  // Handle marking a settlement
  const handleSettlement = (propertyId: number) => {
    if (user && client) {
      if (confirm("Are you sure this client is settling on this property? This will remove both the client and property from the system.")) {
        settlementMutation.mutate({
          clientId: client.id,
          propertyId,
          employeeId: user.id,
        });
      }
    }
  };

  if (isLoadingClient) {
    return (
      <div className="min-h-screen bg-gray-100 flex">
        <Sidebar />
        <div className="flex-1 flex flex-col">
          <Header title="Client Details" />
          <div className="flex-1 p-6 flex items-center justify-center">
            <p>Loading client details...</p>
          </div>
        </div>
      </div>
    );
  }

  if (clientError || !client) {
    return (
      <div className="min-h-screen bg-gray-100 flex">
        <Sidebar />
        <div className="flex-1 flex flex-col">
          <Header title="Client Details" />
          <div className="flex-1 p-6">
            <Button variant="outline" onClick={() => navigate("/employee")} className="mb-4">
              <ArrowLeft className="mr-2 h-4 w-4" /> Back to Dashboard
            </Button>
            <Card>
              <CardContent className="pt-6">
                <p className="text-red-500">
                  Error loading client details. Client may not exist or you don't have
                  permission to view it.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100 flex">
      <Sidebar />
      
      <div className="flex-1 flex flex-col">
        <Header title="Client Details" />
        
        <main className="flex-1 p-6">
          <Button 
            variant="outline" 
            onClick={() => navigate("/employee")} 
            className="mb-4"
          >
            <ArrowLeft className="mr-2 h-4 w-4" /> Back to Dashboard
          </Button>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Client Basic Info */}
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center mb-4">
                  <div 
                    className={`h-12 w-12 rounded-full flex items-center justify-center mr-4 
                      ${client.status === 'hot' ? 'bg-red-100' : 
                        client.status === 'warm' ? 'bg-yellow-100' : 'bg-blue-100'}`}
                  >
                    <span 
                      className={`text-sm font-medium 
                        ${client.status === 'hot' ? 'text-red-800' : 
                          client.status === 'warm' ? 'text-yellow-800' : 'text-blue-800'}`}
                    >
                      {client.name.split(' ').map(n => n[0]).join('')}
                    </span>
                  </div>
                  <div>
                    <h4 className="text-lg font-medium text-gray-900">{client.name}</h4>
                    <p className="text-sm text-gray-500">Client ID: {client.uniqueId}</p>
                  </div>
                </div>
                
                <div className="mb-6">
                  <div className="flex items-center mb-2">
                    <Phone className="h-4 w-4 text-gray-400 mr-2" />
                    <span className="text-sm text-gray-900">{client.phone}</span>
                  </div>
                  <div className="flex items-center mb-2">
                    <Mail className="h-4 w-4 text-gray-400 mr-2" />
                    <span className="text-sm text-gray-900">{client.email}</span>
                  </div>
                  <div className="flex items-center mb-2">
                    <Calendar className="h-4 w-4 text-gray-400 mr-2" />
                    <span className="text-sm text-gray-900">
                      Inquiry: {format(new Date(client.inquiryTime), "MMM d, yyyy")}
                    </span>
                  </div>
                </div>
                
                <div className="mb-4">
                  <h5 className="font-medium text-sm text-gray-700 mb-2">Lead Status</h5>
                  <div className="flex items-center">
                    <StatusBadge status={client.status} />
                    <span className="text-xs text-gray-500 ml-2">
                      {sortedInteractions[0]
                        ? `Updated: ${format(
                            new Date(sortedInteractions[0].timestamp),
                            "MMM d, yyyy"
                          )}`
                        : "Not updated yet"}
                    </span>
                  </div>
                </div>
                
                <div className="mb-4">
                  <h5 className="font-medium text-sm text-gray-700 mb-2">Next Follow-up</h5>
                  {nextFollowUp ? (
                    <p className="text-sm text-gray-900">
                      {format(new Date(nextFollowUp.scheduledTime), "MMM d, h:mm a")}
                    </p>
                  ) : (
                    <p className="text-sm text-gray-500">No follow-up scheduled</p>
                  )}
                </div>
                
                <div className="space-y-2">
                  <Button 
                    className="w-full flex items-center justify-center" 
                    variant="success"
                  >
                    <Phone className="mr-2 h-4 w-4" /> Call Client
                  </Button>
                  
                  <Button 
                    className="w-full flex items-center justify-center" 
                    variant="secondary"
                    onClick={() => setActiveTab("properties")}
                  >
                    <Building className="mr-2 h-4 w-4" /> Book Site Visit
                  </Button>
                  
                  <Button 
                    className="w-full flex items-center justify-center" 
                    variant="default"
                    onClick={() => setActiveTab("properties")}
                  >
                    <CheckCircle className="mr-2 h-4 w-4" /> Mark as Settled
                  </Button>
                </div>
              </CardContent>
            </Card>
            
            {/* Interaction Panel */}
            <div className="md:col-span-2">
              <Card>
                <CardHeader className="pb-0">
                  <Tabs value={activeTab} onValueChange={setActiveTab}>
                    <TabsList className="grid w-full grid-cols-4">
                      <TabsTrigger value="interactions">Interaction Log</TabsTrigger>
                      <TabsTrigger value="followup">Schedule Follow-up</TabsTrigger>
                      <TabsTrigger value="properties">Property Matches</TabsTrigger>
                      <TabsTrigger value="notes">Notes</TabsTrigger>
                    </TabsList>
                  </Tabs>
                </CardHeader>
                
                <CardContent className="pt-6">
                  <TabsContent value="interactions" className="h-[500px] overflow-y-auto">
                    {isLoadingInteractions ? (
                      <p>Loading interactions...</p>
                    ) : sortedInteractions.length === 0 ? (
                      <div className="text-center py-10">
                        <Clock className="h-12 w-12 text-gray-300 mx-auto mb-4" />
                        <p className="text-gray-500">No interactions recorded yet</p>
                        <p className="text-sm text-gray-400 mt-1">
                          Record your first interaction with this client below
                        </p>
                      </div>
                    ) : (
                      <ul className="space-y-4">
                        {sortedInteractions.map((interaction) => (
                          <li 
                            key={interaction.id} 
                            className={`border-l-4 pl-4 pb-4 
                              ${interaction.status === 'hot' ? 'border-red-500' : 
                                interaction.status === 'warm' ? 'border-yellow-500' : 'border-blue-500'}`}
                          >
                            <div className="flex justify-between items-start">
                              <div>
                                <h4 className="text-sm font-medium text-gray-900">
                                  {interaction.interactionType.charAt(0).toUpperCase() + 
                                    interaction.interactionType.slice(1)}
                                </h4>
                                <p className="text-xs text-gray-500">
                                  {format(new Date(interaction.timestamp), "MMM d, yyyy, h:mm a")}
                                </p>
                              </div>
                              <StatusBadge status={interaction.status} />
                            </div>
                            <p className="mt-1 text-sm text-gray-600">{interaction.notes}</p>
                          </li>
                        ))}
                      </ul>
                    )}
                    
                    <Separator className="my-6" />
                    
                    <InteractionForm 
                      clientId={client.id} 
                      employeeId={user?.id || 0} 
                    />
                  </TabsContent>
                  
                  <TabsContent value="followup">
                    <FollowUpForm
                      clientId={client.id}
                      employeeId={user?.id || 0}
                      existingFollowUps={followUps || []}
                    />
                  </TabsContent>
                  
                  <TabsContent value="properties" className="h-[500px] overflow-y-auto">
                    {isLoadingProperties ? (
                      <p>Loading properties...</p>
                    ) : properties?.length === 0 ? (
                      <div className="text-center py-10">
                        <Building className="h-12 w-12 text-gray-300 mx-auto mb-4" />
                        <p className="text-gray-500">No available properties found</p>
                      </div>
                    ) : (
                      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                        {properties?.map((property: any) => (
                          <Card key={property.id}>
                            <CardContent className="p-4">
                              <div className="mb-2">
                                <h3 className="text-lg font-medium">{property.builderName}</h3>
                                <p className="text-sm text-gray-500">
                                  {property.flatType} - {property.flatNumber}
                                </p>
                              </div>
                              <p className="text-sm text-gray-700 mb-3">{property.address}</p>
                              <div className="flex space-x-2">
                                <Button 
                                  size="sm" 
                                  variant="outline" 
                                  onClick={() => handleBookSiteVisit(property.id)}
                                  disabled={siteVisitMutation.isPending}
                                >
                                  <Calendar className="mr-1 h-4 w-4" />
                                  Book Visit
                                </Button>
                                <Button 
                                  size="sm" 
                                  onClick={() => handleSettlement(property.id)}
                                  disabled={settlementMutation.isPending}
                                >
                                  <CheckCircle className="mr-1 h-4 w-4" />
                                  Mark as Settled
                                </Button>
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    )}
                  </TabsContent>
                  
                  <TabsContent value="notes">
                    <div className="h-[500px] overflow-y-auto">
                      <p className="text-gray-500 italic mb-4">
                        Additional client notes and requirements:
                      </p>
                      <div className="bg-gray-50 p-4 rounded-md">
                        {sortedInteractions.map((interaction) => (
                          <div key={interaction.id} className="mb-4 last:mb-0">
                            <p className="text-sm text-gray-700">{interaction.notes}</p>
                            <p className="text-xs text-gray-500 mt-1">
                              From {interaction.interactionType} on {format(new Date(interaction.timestamp), "MMM d, yyyy")}
                            </p>
                          </div>
                        ))}
                        {sortedInteractions.length === 0 && (
                          <p className="text-gray-500">No notes available yet.</p>
                        )}
                      </div>
                    </div>
                  </TabsContent>
                </CardContent>
              </Card>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
