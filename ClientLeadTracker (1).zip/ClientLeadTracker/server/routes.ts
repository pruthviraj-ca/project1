import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, requireRole } from "./auth";
import { parseClientXML, parsePropertyXML } from "./utils/xmlParser";
import { sendFollowUpReminder } from "./mailer";
import { 
  insertClientSchema, 
  insertPropertySchema, 
  insertInteractionSchema,
  insertFollowUpSchema,
  insertSiteVisitSchema,
  insertSettlementSchema
} from "@shared/schema";
import { z } from "zod";
import schedule from "node-schedule";

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up authentication routes
  setupAuth(app);

  // Add development mode middleware to bypass authentication
  if (process.env.NODE_ENV === 'development') {
    // This will automatically log in as a manager in development mode
    app.use(async (req, res, next) => {
      if (!req.isAuthenticated()) {
        try {
          // Find manager user
          const manager = await storage.getUsersByRole('manager');
          if (manager && manager.length > 0) {
            // Set the user manually
            (req as any).user = manager[0];
            (req as any).isAuthenticated = () => true;
          }
        } catch (error) {
          console.error("Auto-login failed:", error);
        }
      }
      next();
    });
  }
  
  // API Routes
  // User related routes
  app.get("/api/employees", async (req, res) => {
    try {
      const employees = await storage.getUsersByRole("employee");
      // Remove password from employees
      const sanitizedEmployees = employees.map(({ password, ...rest }) => rest);
      res.json(sanitizedEmployees);
    } catch (error) {
      console.error("Error fetching employees:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Client related routes
  app.post("/api/clients/upload", requireRole("manager"), async (req, res) => {
    try {
      if (!req.body.xmlData) {
        return res.status(400).json({ message: "XML data is required" });
      }

      const result = await parseClientXML(req.body.xmlData);
      if (!result.success) {
        return res.status(400).json({ message: result.error });
      }

      const clients = [];
      for (const clientData of result.clients) {
        try {
          // Validate client data
          const validatedData = insertClientSchema.parse(clientData);
          
          // Check if client with this uniqueId already exists
          const existingClient = await storage.getClientByUniqueId(validatedData.uniqueId);
          if (existingClient) {
            continue; // Skip existing clients
          }
          
          // Create new client
          const client = await storage.createClient(validatedData);
          clients.push(client);
        } catch (validationError) {
          console.error("Client validation error:", validationError);
          // Continue with other clients even if one fails
        }
      }

      res.status(201).json({ 
        message: `Successfully uploaded ${clients.length} clients`, 
        count: clients.length 
      });
    } catch (error) {
      console.error("Error uploading clients:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/clients", async (req, res) => {
    try {
      let clients;
      const { status, employeeId } = req.query;
      
      if (status) {
        clients = await storage.getClientsByStatus(status as string);
      } else if (employeeId) {
        clients = await storage.getClientsByEmployee(parseInt(employeeId as string));
      } else {
        clients = await storage.getAllClients();
      }
      
      res.json(clients);
    } catch (error) {
      console.error("Error fetching clients:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/clients/unassigned", requireRole("manager"), async (req, res) => {
    try {
      const clients = await storage.getUnassignedClients();
      res.json(clients);
    } catch (error) {
      console.error("Error fetching unassigned clients:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/clients/:id", async (req, res) => {
    try {
      const client = await storage.getClient(parseInt(req.params.id));
      if (!client) {
        return res.status(404).json({ message: "Client not found" });
      }
      res.json(client);
    } catch (error) {
      console.error("Error fetching client:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/clients/distribute", requireRole("manager"), async (req, res) => {
    try {
      const { employeeIds, distributionMethod } = req.body;
      
      if (!employeeIds || !employeeIds.length) {
        return res.status(400).json({ message: "Employee IDs are required" });
      }
      
      const unassignedClients = await storage.getUnassignedClients();
      if (!unassignedClients.length) {
        return res.status(400).json({ message: "No unassigned clients to distribute" });
      }
      
      const results = [];
      
      if (distributionMethod === 'equal') {
        // Distribute clients equally among employees
        const employeeCount = employeeIds.length;
        for (let i = 0; i < unassignedClients.length; i++) {
          const employeeIndex = i % employeeCount;
          const employeeId = employeeIds[employeeIndex];
          const client = unassignedClients[i];
          
          const updatedClient = await storage.assignClientToEmployee(client.id, employeeId);
          if (updatedClient) {
            results.push(updatedClient);
          }
        }
      } else {
        // Manual distribution - just assign all to the first employee
        const employeeId = employeeIds[0];
        for (const client of unassignedClients) {
          const updatedClient = await storage.assignClientToEmployee(client.id, employeeId);
          if (updatedClient) {
            results.push(updatedClient);
          }
        }
      }
      
      res.json({ 
        message: `Successfully distributed ${results.length} clients`, 
        count: results.length 
      });
    } catch (error) {
      console.error("Error distributing clients:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Property related routes
  app.post("/api/properties/upload", requireRole("manager"), async (req, res) => {
    try {
      if (!req.body.xmlData) {
        return res.status(400).json({ message: "XML data is required" });
      }

      const result = await parsePropertyXML(req.body.xmlData);
      if (!result.success) {
        return res.status(400).json({ message: result.error });
      }

      const properties = [];
      for (const propertyData of result.properties) {
        try {
          // Validate property data
          const validatedData = insertPropertySchema.parse(propertyData);
          
          // Check if property with this uniqueId already exists
          const existingProperty = await storage.getPropertyByUniqueId(validatedData.uniqueId);
          if (existingProperty) {
            continue; // Skip existing properties
          }
          
          // Create new property
          const property = await storage.createProperty(validatedData);
          properties.push(property);
        } catch (validationError) {
          console.error("Property validation error:", validationError);
          // Continue with other properties even if one fails
        }
      }

      res.status(201).json({ 
        message: `Successfully uploaded ${properties.length} properties`, 
        count: properties.length 
      });
    } catch (error) {
      console.error("Error uploading properties:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/properties", async (req, res) => {
    try {
      const properties = await storage.getAllProperties();
      res.json(properties);
    } catch (error) {
      console.error("Error fetching properties:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/properties/available", async (req, res) => {
    try {
      const properties = await storage.getAvailableProperties();
      res.json(properties);
    } catch (error) {
      console.error("Error fetching available properties:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Interaction related routes
  app.post("/api/interactions", async (req, res) => {
    try {
      const validatedData = insertInteractionSchema.parse(req.body);
      const interaction = await storage.createInteraction(validatedData);
      res.status(201).json(interaction);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid interaction data", errors: error.errors });
      }
      console.error("Error creating interaction:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/clients/:clientId/interactions", async (req, res) => {
    try {
      const clientId = parseInt(req.params.clientId);
      const interactions = await storage.getInteractionsByClient(clientId);
      res.json(interactions);
    } catch (error) {
      console.error("Error fetching client interactions:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Follow-up related routes
  app.post("/api/followups", async (req, res) => {
    try {
      const validatedData = insertFollowUpSchema.parse(req.body);
      const followUp = await storage.createFollowUp(validatedData);
      
      // Schedule an email reminder
      const followUpTime = new Date(followUp.scheduledTime);
      const reminderTime = new Date(followUpTime.getTime() - 30 * 60 * 1000); // 30 minutes before
      
      if (reminderTime > new Date()) {
        const employee = await storage.getUser(followUp.employeeId);
        const client = await storage.getClient(followUp.clientId);
        
        if (employee && client) {
          // Schedule the reminder email
          schedule.scheduleJob(reminderTime, async () => {
            await sendFollowUpReminder(employee, client, followUp);
          });
        }
      }
      
      res.status(201).json(followUp);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid follow-up data", errors: error.errors });
      }
      console.error("Error creating follow-up:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.patch("/api/followups/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const followUp = await storage.updateFollowUp(id, req.body);
      
      if (!followUp) {
        return res.status(404).json({ message: "Follow-up not found" });
      }
      
      res.json(followUp);
    } catch (error) {
      console.error("Error updating follow-up:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/clients/:clientId/followups", async (req, res) => {
    try {
      const clientId = parseInt(req.params.clientId);
      const followUps = await storage.getFollowUpsByClient(clientId);
      res.json(followUps);
    } catch (error) {
      console.error("Error fetching client follow-ups:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/employees/:employeeId/followups/today", async (req, res) => {
    try {
      const employeeId = parseInt(req.params.employeeId);
      const followUps = await storage.getTodayFollowUps(employeeId);
      res.json(followUps);
    } catch (error) {
      console.error("Error fetching today's follow-ups:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/employees/:employeeId/followups/missed", async (req, res) => {
    try {
      const employeeId = parseInt(req.params.employeeId);
      const followUps = await storage.getMissedFollowUps(employeeId);
      res.json(followUps);
    } catch (error) {
      console.error("Error fetching missed follow-ups:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Site visit related routes
  app.post("/api/sitevisits", async (req, res) => {
    try {
      const validatedData = insertSiteVisitSchema.parse(req.body);
      const siteVisit = await storage.createSiteVisit(validatedData);
      
      res.status(201).json(siteVisit);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid site visit data", errors: error.errors });
      }
      console.error("Error creating site visit:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/employees/:employeeId/sitevisits", async (req, res) => {
    try {
      const employeeId = parseInt(req.params.employeeId);
      const siteVisits = await storage.getSiteVisitsByEmployee(employeeId);
      res.json(siteVisits);
    } catch (error) {
      console.error("Error fetching employee site visits:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Settlement related routes
  app.post("/api/settlements", async (req, res) => {
    try {
      const validatedData = insertSettlementSchema.parse(req.body);
      const settlement = await storage.createSettlement(validatedData);
      
      res.status(201).json(settlement);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid settlement data", errors: error.errors });
      }
      console.error("Error creating settlement:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/employees/:employeeId/settlements", async (req, res) => {
    try {
      const employeeId = parseInt(req.params.employeeId);
      const settlements = await storage.getSettlementsByEmployee(employeeId);
      res.json(settlements);
    } catch (error) {
      console.error("Error fetching employee settlements:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Dashboard and statistics routes
  app.get("/api/stats/clients", async (req, res) => {
    try {
      const stats = await storage.countClientsByStatus();
      res.json(stats);
    } catch (error) {
      console.error("Error fetching client stats:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/stats/properties", async (req, res) => {
    try {
      const stats = await storage.countPropertiesByType();
      res.json(stats);
    } catch (error) {
      console.error("Error fetching property stats:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/stats/employee-performance", requireRole("manager"), async (req, res) => {
    try {
      const stats = await storage.getEmployeePerformanceStats();
      res.json(stats);
    } catch (error) {
      console.error("Error fetching employee performance stats:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/stats/missed-followups", requireRole("manager"), async (req, res) => {
    try {
      const missedFollowUps = await storage.getAllMissedFollowUps();
      res.json(missedFollowUps);
    } catch (error) {
      console.error("Error fetching missed follow-ups:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
