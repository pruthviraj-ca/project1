import { 
  users, User, InsertUser, 
  clients, Client, InsertClient,
  properties, Property, InsertProperty,
  interactions, Interaction, InsertInteraction,
  followUps, FollowUp, InsertFollowUp,
  siteVisits, SiteVisit, InsertSiteVisit,
  settlements, Settlement, InsertSettlement,
  LeadStatusEnum
} from "@shared/schema";
import session from "express-session";
import connectPg from "connect-pg-simple";
import { db, pool } from "./db";
import { eq, and, lt, gte, sql, desc, count, isNull } from "drizzle-orm";
import { IStorage } from "./storage";

const PostgresSessionStore = connectPg(session);

export class DatabaseStorage implements IStorage {
  sessionStore: any;

  constructor() {
    this.sessionStore = new PostgresSessionStore({ 
      pool,
      createTableIfMissing: true
    });

    // Seed initial users if needed
    this.seedInitialData();
  }

  private async seedInitialData() {
    // Check if there are any users in the database
    const existingUsers = await db.select().from(users);
    
    if (existingUsers.length === 0) {
      // Add initial admin user
      await this.createUser({
        username: "admin",
        password: "admin123",
        email: "admin@propertysmart.com",
        role: "manager",
        name: "Admin Manager"
      });
      
      // Add a sample employee
      await this.createUser({
        username: "employee",
        password: "employee123",
        email: "employee@propertysmart.com",
        role: "employee",
        name: "Sample Employee"
      });
    }
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async getAllUsers(): Promise<User[]> {
    return db.select().from(users);
  }

  async getUsersByRole(role: string): Promise<User[]> {
    return db.select().from(users).where(eq(users.role, role));
  }

  // Client methods
  async getClient(id: number): Promise<Client | undefined> {
    const [client] = await db.select().from(clients).where(eq(clients.id, id));
    return client;
  }

  async getClientByUniqueId(uniqueId: string): Promise<Client | undefined> {
    const [client] = await db.select().from(clients).where(eq(clients.uniqueId, uniqueId));
    return client;
  }

  async createClient(insertClient: InsertClient): Promise<Client> {
    const [client] = await db.insert(clients).values(insertClient).returning();
    return client;
  }

  async updateClient(id: number, clientUpdate: Partial<Client>): Promise<Client | undefined> {
    const [updatedClient] = await db
      .update(clients)
      .set(clientUpdate)
      .where(eq(clients.id, id))
      .returning();
    return updatedClient;
  }

  async getAllClients(): Promise<Client[]> {
    return db.select().from(clients);
  }

  async getClientsByStatus(status: string): Promise<Client[]> {
    return db.select().from(clients).where(eq(clients.status, status));
  }

  async getClientsByEmployee(employeeId: number): Promise<Client[]> {
    return db.select().from(clients).where(eq(clients.assignedTo, employeeId));
  }

  async getUnassignedClients(): Promise<Client[]> {
    return db.select().from(clients).where(isNull(clients.assignedTo));
  }

  async assignClientToEmployee(clientId: number, employeeId: number): Promise<Client | undefined> {
    const [updatedClient] = await db
      .update(clients)
      .set({ assignedTo: employeeId })
      .where(eq(clients.id, clientId))
      .returning();
    return updatedClient;
  }

  async countClientsByStatus(): Promise<Record<string, number>> {
    const statusCounts = await db
      .select({
        status: clients.status,
        count: count(),
      })
      .from(clients)
      .groupBy(clients.status);
    
    const totalCount = await db.select({ count: count() }).from(clients);
    
    const result: Record<string, number> = {
      new: 0,
      cold: 0,
      warm: 0,
      hot: 0,
      total: totalCount[0]?.count || 0
    };
    
    statusCounts.forEach(item => {
      result[item.status] = item.count;
    });
    
    return result;
  }

  // Property methods
  async getProperty(id: number): Promise<Property | undefined> {
    const [property] = await db.select().from(properties).where(eq(properties.id, id));
    return property;
  }

  async getPropertyByUniqueId(uniqueId: string): Promise<Property | undefined> {
    const [property] = await db.select().from(properties).where(eq(properties.uniqueId, uniqueId));
    return property;
  }

  async createProperty(insertProperty: InsertProperty): Promise<Property> {
    const [property] = await db.insert(properties).values(insertProperty).returning();
    return property;
  }

  async updateProperty(id: number, propertyUpdate: Partial<Property>): Promise<Property | undefined> {
    const [updatedProperty] = await db
      .update(properties)
      .set(propertyUpdate)
      .where(eq(properties.id, id))
      .returning();
    return updatedProperty;
  }

  async getAllProperties(): Promise<Property[]> {
    return db.select().from(properties);
  }

  async getAvailableProperties(): Promise<Property[]> {
    return db.select().from(properties).where(eq(properties.isAvailable, true));
  }

  async countPropertiesByType(): Promise<Record<string, number>> {
    const typeCounts = await db
      .select({
        flatType: properties.flatType,
        count: count(),
      })
      .from(properties)
      .groupBy(properties.flatType);
    
    const result: Record<string, number> = {};
    
    typeCounts.forEach(item => {
      result[item.flatType] = item.count;
    });
    
    return result;
  }

  // Interaction methods
  async createInteraction(insertInteraction: InsertInteraction): Promise<Interaction> {
    const [interaction] = await db.insert(interactions).values(insertInteraction).returning();
    
    // Update client status based on interaction
    await db
      .update(clients)
      .set({ status: insertInteraction.status })
      .where(eq(clients.id, insertInteraction.clientId));
    
    return interaction;
  }

  async getInteractionsByClient(clientId: number): Promise<Interaction[]> {
    return db
      .select()
      .from(interactions)
      .where(eq(interactions.clientId, clientId))
      .orderBy(desc(interactions.timestamp));
  }

  async getInteractionsByEmployee(employeeId: number): Promise<Interaction[]> {
    return db
      .select()
      .from(interactions)
      .where(eq(interactions.employeeId, employeeId))
      .orderBy(desc(interactions.timestamp));
  }

  // Follow-up methods
  async createFollowUp(insertFollowUp: InsertFollowUp): Promise<FollowUp> {
    const [followUp] = await db.insert(followUps).values(insertFollowUp).returning();
    return followUp;
  }

  async updateFollowUp(id: number, followUpUpdate: Partial<FollowUp>): Promise<FollowUp | undefined> {
    const [updatedFollowUp] = await db
      .update(followUps)
      .set(followUpUpdate)
      .where(eq(followUps.id, id))
      .returning();
    return updatedFollowUp;
  }

  async getFollowUpById(id: number): Promise<FollowUp | undefined> {
    const [followUp] = await db.select().from(followUps).where(eq(followUps.id, id));
    return followUp;
  }

  async getFollowUpsByClient(clientId: number): Promise<FollowUp[]> {
    return db
      .select()
      .from(followUps)
      .where(eq(followUps.clientId, clientId))
      .orderBy(followUps.scheduledTime);
  }

  async getFollowUpsByEmployee(employeeId: number): Promise<FollowUp[]> {
    return db
      .select()
      .from(followUps)
      .where(eq(followUps.employeeId, employeeId))
      .orderBy(followUps.scheduledTime);
  }

  async getTodayFollowUps(employeeId: number): Promise<FollowUp[]> {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);
    
    return db
      .select()
      .from(followUps)
      .where(and(
        eq(followUps.employeeId, employeeId),
        gte(followUps.scheduledTime, today),
        lt(followUps.scheduledTime, tomorrow)
      ))
      .orderBy(followUps.scheduledTime);
  }

  async getMissedFollowUps(employeeId: number): Promise<FollowUp[]> {
    const now = new Date();
    
    return db
      .select()
      .from(followUps)
      .where(and(
        eq(followUps.employeeId, employeeId),
        eq(followUps.completed, false),
        lt(followUps.scheduledTime, now)
      ))
      .orderBy(desc(followUps.scheduledTime));
  }

  async getAllMissedFollowUps(): Promise<FollowUp[]> {
    const now = new Date();
    
    return db
      .select()
      .from(followUps)
      .where(and(
        eq(followUps.completed, false),
        lt(followUps.scheduledTime, now)
      ))
      .orderBy(desc(followUps.scheduledTime));
  }

  // Site visit methods
  async createSiteVisit(insertSiteVisit: InsertSiteVisit): Promise<SiteVisit> {
    const [siteVisit] = await db.insert(siteVisits).values(insertSiteVisit).returning();
    return siteVisit;
  }

  async updateSiteVisit(id: number, siteVisitUpdate: Partial<SiteVisit>): Promise<SiteVisit | undefined> {
    const [updatedSiteVisit] = await db
      .update(siteVisits)
      .set(siteVisitUpdate)
      .where(eq(siteVisits.id, id))
      .returning();
    return updatedSiteVisit;
  }

  async getSiteVisitById(id: number): Promise<SiteVisit | undefined> {
    const [siteVisit] = await db.select().from(siteVisits).where(eq(siteVisits.id, id));
    return siteVisit;
  }

  async getSiteVisitsByClient(clientId: number): Promise<SiteVisit[]> {
    return db
      .select()
      .from(siteVisits)
      .where(eq(siteVisits.clientId, clientId))
      .orderBy(siteVisits.scheduledTime);
  }

  async getSiteVisitsByEmployee(employeeId: number): Promise<SiteVisit[]> {
    return db
      .select()
      .from(siteVisits)
      .where(eq(siteVisits.employeeId, employeeId))
      .orderBy(siteVisits.scheduledTime);
  }

  // Settlement methods
  async createSettlement(insertSettlement: InsertSettlement): Promise<Settlement> {
    const [settlement] = await db
      .insert(settlements)
      .values(insertSettlement)
      .returning();
    
    // Mark the client as settled
    await db
      .update(clients)
      .set({ isSettled: true })
      .where(eq(clients.id, insertSettlement.clientId));
    
    // Mark the property as unavailable
    await db
      .update(properties)
      .set({ isAvailable: false })
      .where(eq(properties.id, insertSettlement.propertyId));
    
    return settlement;
  }

  async getSettlementsByEmployee(employeeId: number): Promise<Settlement[]> {
    return db
      .select()
      .from(settlements)
      .where(eq(settlements.employeeId, employeeId))
      .orderBy(desc(settlements.settlementDate));
  }

  async countSettlementsByEmployee(): Promise<Record<number, number>> {
    const employeeSettlements = await db
      .select({
        employeeId: settlements.employeeId,
        count: count(),
      })
      .from(settlements)
      .groupBy(settlements.employeeId);
    
    const result: Record<number, number> = {};
    
    employeeSettlements.forEach(item => {
      result[item.employeeId] = item.count;
    });
    
    return result;
  }

  // Statistics and reports
  async getEmployeePerformanceStats(): Promise<any[]> {
    const employees = await this.getUsersByRole("employee");
    const settlementCounts = await this.countSettlementsByEmployee();
    
    return Promise.all(employees.map(async (employee) => {
      const clients = await this.getClientsByEmployee(employee.id);
      
      // Count clients by status
      const clientsByStatus = clients.reduce(
        (acc, client) => {
          if (client.status === "hot") acc.hot++;
          else if (client.status === "warm") acc.warm++;
          else if (client.status === "cold") acc.cold++;
          return acc;
        },
        { hot: 0, warm: 0, cold: 0 }
      );
      
      const missedFollowUps = await this.getMissedFollowUps(employee.id);
      const followUps = await this.getFollowUpsByEmployee(employee.id);
      const upcomingFollowUps = followUps.filter(
        fu => !fu.completed && new Date(fu.scheduledTime) > new Date()
      );
      
      return {
        id: employee.id,
        name: employee.name,
        email: employee.email,
        assignedLeads: clients.length,
        leadDistribution: {
          hot: clientsByStatus.hot,
          warm: clientsByStatus.warm,
          cold: clientsByStatus.cold,
        },
        upcomingMeetings: upcomingFollowUps.length,
        missedFollowUps: missedFollowUps.length,
        settlements: settlementCounts[employee.id] || 0,
      };
    }));
  }
}