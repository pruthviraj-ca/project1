import { 
  users, User, InsertUser, 
  clients, Client, InsertClient,
  properties, Property, InsertProperty,
  interactions, Interaction, InsertInteraction,
  followUps, FollowUp, InsertFollowUp,
  siteVisits, SiteVisit, InsertSiteVisit,
  settlements, Settlement, InsertSettlement,
  LeadStatusEnum
} from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";

const MemoryStore = createMemoryStore(session);
import connectPg from "connect-pg-simple";
import { db, pool } from "./db";
import { eq, and, lt, gte, sql, desc, isNull, count } from "drizzle-orm";

const PostgresSessionStore = connectPg(session);

export interface IStorage {
  // User-related operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getAllUsers(): Promise<User[]>;
  getUsersByRole(role: string): Promise<User[]>;

  // Client-related operations
  getClient(id: number): Promise<Client | undefined>;
  getClientByUniqueId(uniqueId: string): Promise<Client | undefined>;
  createClient(client: InsertClient): Promise<Client>;
  updateClient(id: number, client: Partial<Client>): Promise<Client | undefined>;
  getAllClients(): Promise<Client[]>;
  getClientsByStatus(status: string): Promise<Client[]>;
  getClientsByEmployee(employeeId: number): Promise<Client[]>;
  getUnassignedClients(): Promise<Client[]>;
  assignClientToEmployee(clientId: number, employeeId: number): Promise<Client | undefined>;
  countClientsByStatus(): Promise<Record<string, number>>;

  // Property-related operations
  getProperty(id: number): Promise<Property | undefined>;
  getPropertyByUniqueId(uniqueId: string): Promise<Property | undefined>;
  createProperty(property: InsertProperty): Promise<Property>;
  updateProperty(id: number, property: Partial<Property>): Promise<Property | undefined>;
  getAllProperties(): Promise<Property[]>;
  getAvailableProperties(): Promise<Property[]>;
  countPropertiesByType(): Promise<Record<string, number>>;

  // Interaction-related operations
  createInteraction(interaction: InsertInteraction): Promise<Interaction>;
  getInteractionsByClient(clientId: number): Promise<Interaction[]>;
  getInteractionsByEmployee(employeeId: number): Promise<Interaction[]>;

  // Follow-up related operations
  createFollowUp(followUp: InsertFollowUp): Promise<FollowUp>;
  updateFollowUp(id: number, followUp: Partial<FollowUp>): Promise<FollowUp | undefined>;
  getFollowUpById(id: number): Promise<FollowUp | undefined>;
  getFollowUpsByClient(clientId: number): Promise<FollowUp[]>;
  getFollowUpsByEmployee(employeeId: number): Promise<FollowUp[]>;
  getTodayFollowUps(employeeId: number): Promise<FollowUp[]>;
  getMissedFollowUps(employeeId: number): Promise<FollowUp[]>;
  getAllMissedFollowUps(): Promise<FollowUp[]>;

  // Site visit related operations
  createSiteVisit(siteVisit: InsertSiteVisit): Promise<SiteVisit>;
  updateSiteVisit(id: number, siteVisit: Partial<SiteVisit>): Promise<SiteVisit | undefined>;
  getSiteVisitById(id: number): Promise<SiteVisit | undefined>;
  getSiteVisitsByClient(clientId: number): Promise<SiteVisit[]>;
  getSiteVisitsByEmployee(employeeId: number): Promise<SiteVisit[]>;

  // Settlement related operations
  createSettlement(settlement: InsertSettlement): Promise<Settlement>;
  getSettlementsByEmployee(employeeId: number): Promise<Settlement[]>;
  countSettlementsByEmployee(): Promise<Record<number, number>>;

  // Statistics and reports
  getEmployeePerformanceStats(): Promise<any[]>;

  // Session store
  sessionStore: any;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private clients: Map<number, Client>;
  private properties: Map<number, Property>;
  private interactions: Map<number, Interaction>;
  private followUps: Map<number, FollowUp>;
  private siteVisits: Map<number, SiteVisit>;
  private settlements: Map<number, Settlement>;
  
  sessionStore: any;
  
  private userCurrentId: number;
  private clientCurrentId: number;
  private propertyCurrentId: number;
  private interactionCurrentId: number;
  private followUpCurrentId: number;
  private siteVisitCurrentId: number;
  private settlementCurrentId: number;

  constructor() {
    this.users = new Map();
    this.clients = new Map();
    this.properties = new Map();
    this.interactions = new Map();
    this.followUps = new Map();
    this.siteVisits = new Map();
    this.settlements = new Map();
    
    this.userCurrentId = 1;
    this.clientCurrentId = 1;
    this.propertyCurrentId = 1;
    this.interactionCurrentId = 1;
    this.followUpCurrentId = 1;
    this.siteVisitCurrentId = 1;
    this.settlementCurrentId = 1;
    
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000, // 24 hours in ms
    });
    
    // Add initial admin user
    this.createUser({
      username: "admin",
      password: "admin123",
      email: "admin@propertysmart.com",
      role: "manager",
      name: "Admin Manager"
    });
    
    // Add a sample employee
    this.createUser({
      username: "employee",
      password: "employee123",
      email: "employee@propertysmart.com",
      role: "employee",
      name: "Sample Employee"
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userCurrentId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getAllUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  async getUsersByRole(role: string): Promise<User[]> {
    return Array.from(this.users.values()).filter(user => user.role === role);
  }

  // Client methods
  async getClient(id: number): Promise<Client | undefined> {
    return this.clients.get(id);
  }

  async getClientByUniqueId(uniqueId: string): Promise<Client | undefined> {
    return Array.from(this.clients.values()).find(
      (client) => client.uniqueId === uniqueId,
    );
  }

  async createClient(insertClient: InsertClient): Promise<Client> {
    const id = this.clientCurrentId++;
    const client: Client = { ...insertClient, id };
    this.clients.set(id, client);
    return client;
  }

  async updateClient(id: number, clientUpdate: Partial<Client>): Promise<Client | undefined> {
    const client = this.clients.get(id);
    if (!client) return undefined;
    
    const updatedClient = { ...client, ...clientUpdate };
    this.clients.set(id, updatedClient);
    return updatedClient;
  }

  async getAllClients(): Promise<Client[]> {
    return Array.from(this.clients.values());
  }

  async getClientsByStatus(status: string): Promise<Client[]> {
    return Array.from(this.clients.values()).filter(client => client.status === status);
  }

  async getClientsByEmployee(employeeId: number): Promise<Client[]> {
    return Array.from(this.clients.values()).filter(client => client.assignedTo === employeeId);
  }

  async getUnassignedClients(): Promise<Client[]> {
    return Array.from(this.clients.values()).filter(client => !client.assignedTo);
  }

  async assignClientToEmployee(clientId: number, employeeId: number): Promise<Client | undefined> {
    const client = this.clients.get(clientId);
    if (!client) return undefined;
    
    const updatedClient = { ...client, assignedTo: employeeId };
    this.clients.set(clientId, updatedClient);
    return updatedClient;
  }

  async countClientsByStatus(): Promise<Record<string, number>> {
    const clients = Array.from(this.clients.values());
    const counts: Record<string, number> = {
      new: 0,
      cold: 0,
      warm: 0,
      hot: 0,
      total: clients.length
    };
    
    clients.forEach(client => {
      if (counts[client.status] !== undefined) {
        counts[client.status]++;
      }
    });
    
    return counts;
  }

  // Property methods
  async getProperty(id: number): Promise<Property | undefined> {
    return this.properties.get(id);
  }

  async getPropertyByUniqueId(uniqueId: string): Promise<Property | undefined> {
    return Array.from(this.properties.values()).find(
      (property) => property.uniqueId === uniqueId,
    );
  }

  async createProperty(insertProperty: InsertProperty): Promise<Property> {
    const id = this.propertyCurrentId++;
    const property: Property = { ...insertProperty, id };
    this.properties.set(id, property);
    return property;
  }

  async updateProperty(id: number, propertyUpdate: Partial<Property>): Promise<Property | undefined> {
    const property = this.properties.get(id);
    if (!property) return undefined;
    
    const updatedProperty = { ...property, ...propertyUpdate };
    this.properties.set(id, updatedProperty);
    return updatedProperty;
  }

  async getAllProperties(): Promise<Property[]> {
    return Array.from(this.properties.values());
  }

  async getAvailableProperties(): Promise<Property[]> {
    return Array.from(this.properties.values()).filter(property => property.isAvailable);
  }

  async countPropertiesByType(): Promise<Record<string, number>> {
    const properties = Array.from(this.properties.values());
    const counts: Record<string, number> = {};
    
    properties.forEach(property => {
      if (!counts[property.flatType]) {
        counts[property.flatType] = 0;
      }
      counts[property.flatType]++;
    });
    
    return counts;
  }

  // Interaction methods
  async createInteraction(insertInteraction: InsertInteraction): Promise<Interaction> {
    const id = this.interactionCurrentId++;
    const interaction: Interaction = { ...insertInteraction, id };
    this.interactions.set(id, interaction);
    
    // Update client status based on interaction
    const client = this.clients.get(insertInteraction.clientId);
    if (client) {
      client.status = insertInteraction.status;
      this.clients.set(client.id, client);
    }
    
    return interaction;
  }

  async getInteractionsByClient(clientId: number): Promise<Interaction[]> {
    return Array.from(this.interactions.values())
      .filter(interaction => interaction.clientId === clientId)
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }

  async getInteractionsByEmployee(employeeId: number): Promise<Interaction[]> {
    return Array.from(this.interactions.values())
      .filter(interaction => interaction.employeeId === employeeId)
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }

  // Follow-up methods
  async createFollowUp(insertFollowUp: InsertFollowUp): Promise<FollowUp> {
    const id = this.followUpCurrentId++;
    const followUp: FollowUp = { ...insertFollowUp, id };
    this.followUps.set(id, followUp);
    return followUp;
  }

  async updateFollowUp(id: number, followUpUpdate: Partial<FollowUp>): Promise<FollowUp | undefined> {
    const followUp = this.followUps.get(id);
    if (!followUp) return undefined;
    
    const updatedFollowUp = { ...followUp, ...followUpUpdate };
    this.followUps.set(id, updatedFollowUp);
    return updatedFollowUp;
  }

  async getFollowUpById(id: number): Promise<FollowUp | undefined> {
    return this.followUps.get(id);
  }

  async getFollowUpsByClient(clientId: number): Promise<FollowUp[]> {
    return Array.from(this.followUps.values())
      .filter(followUp => followUp.clientId === clientId)
      .sort((a, b) => new Date(a.scheduledTime).getTime() - new Date(b.scheduledTime).getTime());
  }

  async getFollowUpsByEmployee(employeeId: number): Promise<FollowUp[]> {
    return Array.from(this.followUps.values())
      .filter(followUp => followUp.employeeId === employeeId)
      .sort((a, b) => new Date(a.scheduledTime).getTime() - new Date(b.scheduledTime).getTime());
  }

  async getTodayFollowUps(employeeId: number): Promise<FollowUp[]> {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);
    
    return Array.from(this.followUps.values())
      .filter(followUp => 
        followUp.employeeId === employeeId && 
        new Date(followUp.scheduledTime) >= today &&
        new Date(followUp.scheduledTime) < tomorrow
      )
      .sort((a, b) => new Date(a.scheduledTime).getTime() - new Date(b.scheduledTime).getTime());
  }

  async getMissedFollowUps(employeeId: number): Promise<FollowUp[]> {
    const now = new Date();
    
    return Array.from(this.followUps.values())
      .filter(followUp => 
        followUp.employeeId === employeeId && 
        !followUp.completed &&
        new Date(followUp.scheduledTime) < now
      )
      .sort((a, b) => new Date(b.scheduledTime).getTime() - new Date(a.scheduledTime).getTime());
  }

  async getAllMissedFollowUps(): Promise<FollowUp[]> {
    const now = new Date();
    
    return Array.from(this.followUps.values())
      .filter(followUp => 
        !followUp.completed &&
        new Date(followUp.scheduledTime) < now
      )
      .sort((a, b) => new Date(b.scheduledTime).getTime() - new Date(a.scheduledTime).getTime());
  }

  // Site visit methods
  async createSiteVisit(insertSiteVisit: InsertSiteVisit): Promise<SiteVisit> {
    const id = this.siteVisitCurrentId++;
    const siteVisit: SiteVisit = { ...insertSiteVisit, id };
    this.siteVisits.set(id, siteVisit);
    return siteVisit;
  }

  async updateSiteVisit(id: number, siteVisitUpdate: Partial<SiteVisit>): Promise<SiteVisit | undefined> {
    const siteVisit = this.siteVisits.get(id);
    if (!siteVisit) return undefined;
    
    const updatedSiteVisit = { ...siteVisit, ...siteVisitUpdate };
    this.siteVisits.set(id, updatedSiteVisit);
    return updatedSiteVisit;
  }

  async getSiteVisitById(id: number): Promise<SiteVisit | undefined> {
    return this.siteVisits.get(id);
  }

  async getSiteVisitsByClient(clientId: number): Promise<SiteVisit[]> {
    return Array.from(this.siteVisits.values())
      .filter(siteVisit => siteVisit.clientId === clientId)
      .sort((a, b) => new Date(a.scheduledTime).getTime() - new Date(b.scheduledTime).getTime());
  }

  async getSiteVisitsByEmployee(employeeId: number): Promise<SiteVisit[]> {
    return Array.from(this.siteVisits.values())
      .filter(siteVisit => siteVisit.employeeId === employeeId)
      .sort((a, b) => new Date(a.scheduledTime).getTime() - new Date(b.scheduledTime).getTime());
  }

  // Settlement methods
  async createSettlement(insertSettlement: InsertSettlement): Promise<Settlement> {
    const id = this.settlementCurrentId++;
    const settlement: Settlement = { ...insertSettlement, id };
    this.settlements.set(id, settlement);
    
    // Mark the client as settled
    const client = this.clients.get(insertSettlement.clientId);
    if (client) {
      client.isSettled = true;
      this.clients.set(client.id, client);
    }
    
    // Mark the property as unavailable
    const property = this.properties.get(insertSettlement.propertyId);
    if (property) {
      property.isAvailable = false;
      this.properties.set(property.id, property);
    }
    
    return settlement;
  }

  async getSettlementsByEmployee(employeeId: number): Promise<Settlement[]> {
    return Array.from(this.settlements.values())
      .filter(settlement => settlement.employeeId === employeeId)
      .sort((a, b) => new Date(b.settlementDate).getTime() - new Date(a.settlementDate).getTime());
  }

  async countSettlementsByEmployee(): Promise<Record<number, number>> {
    const settlements = Array.from(this.settlements.values());
    const counts: Record<number, number> = {};
    
    settlements.forEach(settlement => {
      if (!counts[settlement.employeeId]) {
        counts[settlement.employeeId] = 0;
      }
      counts[settlement.employeeId]++;
    });
    
    return counts;
  }

  // Statistics and reports
  async getEmployeePerformanceStats(): Promise<any[]> {
    const employees = await this.getUsersByRole("employee");
    const settlementCounts = await this.countSettlementsByEmployee();
    
    return Promise.all(employees.map(async (employee) => {
      const clients = await this.getClientsByEmployee(employee.id);
      const hotLeads = clients.filter(c => c.status === "hot").length;
      const warmLeads = clients.filter(c => c.status === "warm").length;
      const coldLeads = clients.filter(c => c.status === "cold").length;
      const missedFollowUps = await this.getMissedFollowUps(employee.id);
      const upcomingFollowUps = (await this.getFollowUpsByEmployee(employee.id))
        .filter(fu => !fu.completed && new Date(fu.scheduledTime) > new Date());
      
      return {
        id: employee.id,
        name: employee.name,
        email: employee.email,
        assignedLeads: clients.length,
        leadDistribution: {
          hot: hotLeads,
          warm: warmLeads,
          cold: coldLeads,
        },
        upcomingMeetings: upcomingFollowUps.length,
        missedFollowUps: missedFollowUps.length,
        settlements: settlementCounts[employee.id] || 0,
      };
    }));
  }
}

// Import DatabaseStorage
import { DatabaseStorage } from "./databaseStorage";

// Use DatabaseStorage instead of MemStorage
export const storage = new DatabaseStorage();
