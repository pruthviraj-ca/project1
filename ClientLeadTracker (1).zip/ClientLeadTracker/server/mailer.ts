import nodemailer from "nodemailer";
import { User, Client, FollowUp } from "@shared/schema";

// Configure nodemailer with environment variables or defaults
const transport = nodemailer.createTransport({
  host: process.env.SMTP_HOST || "smtp.mailtrap.io",
  port: parseInt(process.env.SMTP_PORT || "2525"),
  auth: {
    user: process.env.SMTP_USER || "your_mailtrap_user",
    pass: process.env.SMTP_PASS || "your_mailtrap_password",
  },
});

export async function sendFollowUpReminder(employee: User, client: Client, followUp: FollowUp) {
  try {
    // Format the scheduled time
    const scheduledTime = new Date(followUp.scheduledTime).toLocaleString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "numeric",
      minute: "2-digit",
      hour12: true,
    });

    const html = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #e0e0e0; border-radius: 5px;">
        <h2 style="color: #3b82f6; margin-bottom: 20px;">Follow-up Reminder</h2>
        <p>Hello ${employee.name},</p>
        <p>This is a reminder for your upcoming follow-up:</p>
        <div style="background-color: #f8fafc; padding: 15px; border-radius: 5px; margin: 15px 0;">
          <p><strong>Client:</strong> ${client.name}</p>
          <p><strong>Phone:</strong> ${client.phone}</p>
          <p><strong>Email:</strong> ${client.email}</p>
          <p><strong>Scheduled Time:</strong> ${scheduledTime}</p>
          ${followUp.notes ? `<p><strong>Notes:</strong> ${followUp.notes}</p>` : ''}
        </div>
        <p>Please make sure to complete this follow-up on time. If you need to reschedule, please update the follow-up in the system.</p>
        <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #e0e0e0; font-size: 12px; color: #6b7280;">
          <p>This is an automated message from PropertySmart CRM. Please do not reply to this email.</p>
        </div>
      </div>
    `;

    const mailOptions = {
      from: `"PropertySmart CRM" <noreply@propertysmart.com>`,
      to: employee.email,
      subject: `Follow-up Reminder: ${client.name} at ${scheduledTime}`,
      html,
    };

    const info = await transport.sendMail(mailOptions);
    console.log("Follow-up reminder email sent:", info.messageId);
    return { success: true, messageId: info.messageId };
  } catch (error) {
    console.error("Error sending follow-up reminder email:", error);
    return { success: false, error };
  }
}

export async function sendMissedFollowUpAlert(employee: User, client: Client, followUp: FollowUp) {
  try {
    // Format the scheduled time
    const scheduledTime = new Date(followUp.scheduledTime).toLocaleString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "numeric",
      minute: "2-digit",
      hour12: true,
    });

    const html = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #e0e0e0; border-radius: 5px;">
        <h2 style="color: #ef4444; margin-bottom: 20px;">Missed Follow-up Alert</h2>
        <p>Hello ${employee.name},</p>
        <p>You have <strong style="color: #ef4444;">missed</strong> a follow-up:</p>
        <div style="background-color: #fee2e2; padding: 15px; border-radius: 5px; margin: 15px 0;">
          <p><strong>Client:</strong> ${client.name}</p>
          <p><strong>Phone:</strong> ${client.phone}</p>
          <p><strong>Email:</strong> ${client.email}</p>
          <p><strong>Scheduled Time:</strong> ${scheduledTime}</p>
          ${followUp.notes ? `<p><strong>Notes:</strong> ${followUp.notes}</p>` : ''}
        </div>
        <p>Please contact the client as soon as possible and update the follow-up status in the system.</p>
        <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #e0e0e0; font-size: 12px; color: #6b7280;">
          <p>This is an automated message from PropertySmart CRM. Please do not reply to this email.</p>
        </div>
      </div>
    `;

    const mailOptions = {
      from: `"PropertySmart CRM" <noreply@propertysmart.com>`,
      to: employee.email,
      subject: `MISSED FOLLOW-UP: ${client.name}`,
      html,
    };

    const info = await transport.sendMail(mailOptions);
    console.log("Missed follow-up alert email sent:", info.messageId);
    return { success: true, messageId: info.messageId };
  } catch (error) {
    console.error("Error sending missed follow-up alert email:", error);
    return { success: false, error };
  }
}
