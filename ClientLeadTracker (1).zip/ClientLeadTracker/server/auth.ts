import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import { Express, Request, Response, NextFunction } from "express";
import session from "express-session";
import { scrypt, randomBytes, timingSafeEqual } from "crypto";
import { promisify } from "util";
import { storage } from "./storage";
import { User, InsertUser } from "@shared/schema";

declare global {
  namespace Express {
    // Define the User interface for Express.User
    interface User {
      id: number;
      username: string;
      password: string;
      email: string; 
      role: string;
      name: string;
    }
  }
}

const scryptAsync = promisify(scrypt);

async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

async function comparePasswords(supplied: string, stored: string) {
  const [hashed, salt] = stored.split(".");
  const hashedBuf = Buffer.from(hashed, "hex");
  const suppliedBuf = (await scryptAsync(supplied, salt, 64)) as Buffer;
  return timingSafeEqual(hashedBuf, suppliedBuf);
}

export function setupAuth(app: Express) {
  const sessionSettings: session.SessionOptions = {
    secret: process.env.SESSION_SECRET || "propertysmart-crm-session-secret",
    resave: false,
    saveUninitialized: false,
    store: storage.sessionStore,
    cookie: {
      maxAge: 24 * 60 * 60 * 1000, // 24 hours
    },
  };

  app.set("trust proxy", 1);
  app.use(session(sessionSettings));
  app.use(passport.initialize());
  app.use(passport.session());

  passport.use(
    new LocalStrategy(async (username, password, done) => {
      try {
        const user = await storage.getUserByUsername(username);
        if (!user || !(await comparePasswords(password, user.password))) {
          return done(null, false);
        } else {
          return done(null, user);
        }
      } catch (error) {
        return done(error);
      }
    }),
  );

  passport.serializeUser((user, done) => done(null, user.id));
  passport.deserializeUser(async (id: number, done) => {
    try {
      const user = await storage.getUser(id);
      done(null, user);
    } catch (error) {
      done(error);
    }
  });

  app.post("/api/register", async (req, res, next) => {
    try {
      const { username, password, email, name, role } = req.body;
      
      // Validate required fields
      if (!username || !password || !email || !name) {
        return res.status(400).json({ message: "All fields are required" });
      }
      
      // Check if username already exists
      const existingUser = await storage.getUserByUsername(username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }
      
      // Create new user with hashed password
      const hashedPassword = await hashPassword(password);
      const user = await storage.createUser({
        username,
        password: hashedPassword,
        email,
        name,
        role: role || "employee", // Default to employee if role not specified
      });
      
      // Strip password from response
      const { password: _, ...userWithoutPassword } = user;
      
      req.login(user, (err) => {
        if (err) return next(err);
        res.status(201).json(userWithoutPassword);
      });
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/login", (req, res, next) => {
    passport.authenticate("local", (err: Error | null, user: any, info: any) => {
      if (err) return next(err);
      if (!user) return res.status(401).json({ message: "Invalid username or password" });
      
      req.login(user, (loginErr) => {
        if (loginErr) return next(loginErr);
        
        // Strip password from response
        const { password: _, ...userWithoutPassword } = user;
        
        return res.status(200).json(userWithoutPassword);
      });
    })(req, res, next);
  });

  app.post("/api/logout", (req, res, next) => {
    req.logout((err) => {
      if (err) return next(err);
      res.sendStatus(200);
    });
  });

  app.get("/api/user", async (req, res) => {
    // In development mode, automatically authenticate as a manager if not authenticated
    if (!req.isAuthenticated() && process.env.NODE_ENV === 'development') {
      try {
        // Find manager user
        const managers = await storage.getUsersByRole('manager');
        if (managers && managers.length > 0) {
          // Strip password from response
          const { password: _, ...userWithoutPassword } = managers[0];
          return res.json(userWithoutPassword);
        }
      } catch (error) {
        console.error("Auto-login failed in /api/user:", error);
      }
    }
    
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    // Strip password from response
    const { password: _, ...userWithoutPassword } = req.user as User;
    
    res.json(userWithoutPassword);
  });
}

// Middleware to check if user is authenticated and has required access
export function requireRole(requiredRole: string) {
  return async (req: Request, res: Response, next: NextFunction) => {
    // In development mode, auto-authenticate as manager if not authenticated
    if (!req.isAuthenticated() && process.env.NODE_ENV === 'development') {
      try {
        // Find manager user
        const managers = await storage.getUsersByRole('manager');
        if (managers && managers.length > 0) {
          // Set the user manually
          (req as any).user = managers[0];
          (req as any).isAuthenticated = () => true;
        }
      } catch (error) {
        console.error("Auto-login failed in requireRole:", error);
      }
    }
    
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Authentication required" });
    }
    
    const user = req.user as User;
    
    // If requiring manager role, only managers can access
    // If requiring employee role, both employees and managers can access
    if (requiredRole === "manager" && user.role !== "manager") {
      return res.status(403).json({ message: "Access denied: Manager role required" });
    }
    
    next();
  };
}
