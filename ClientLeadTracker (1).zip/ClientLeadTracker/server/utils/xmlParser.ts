import { parseString } from 'xml2js';
import { promisify } from 'util';
import { InsertClient, InsertProperty } from '@shared/schema';

const parseXml = promisify(parseString);

export async function parseClientXML(xmlData: string) {
  try {
    const result = await parseXml(xmlData, { explicitArray: false });
    
    // Check for Leads format (from client_leads.xml)
    if (result.Leads && result.Leads.Lead) {
      const leadElements = Array.isArray(result.Leads.Lead) 
        ? result.Leads.Lead 
        : [result.Leads.Lead];
      
      const clients: InsertClient[] = [];
      
      for (const lead of leadElements) {
        try {
          // Extract client data from XML elements
          const uniqueId = lead.ClientID;
          const name = lead.Name;
          const phone = lead.Phone;
          const email = lead.Email;
          const inquiryTimeStr = lead.InquiryTime;
          
          // Validate required fields
          if (!uniqueId || !name || !phone || !email || !inquiryTimeStr) {
            console.error("Missing required client fields", { uniqueId, name, phone, email, inquiryTimeStr });
            continue;
          }
          
          // Parse inquiry time
          let inquiryTime: Date;
          try {
            inquiryTime = new Date(inquiryTimeStr);
            if (isNaN(inquiryTime.getTime())) {
              throw new Error("Invalid date format");
            }
          } catch (error) {
            console.error("Invalid inquiry time format", inquiryTimeStr);
            inquiryTime = new Date(); // Fallback to current time
          }
          
          clients.push({
            uniqueId,
            name,
            phone,
            email,
            inquiryTime,
            status: "new",
            assignedTo: null,
            isSettled: false,
          });
        } catch (error) {
          console.error("Error parsing lead element", error);
          // Continue with next client
        }
      }
      
      return { success: true, clients };
    }
    
    // Traditional format check (fallback)
    if (result.clients && result.clients.client) {
      const clientElements = Array.isArray(result.clients.client) 
        ? result.clients.client 
        : [result.clients.client];
      
      const clients: InsertClient[] = [];
      
      for (const clientElement of clientElements) {
        try {
          // Extract client data from XML elements
          const uniqueId = clientElement.uniqueId || clientElement.id || clientElement.clientId;
          const name = clientElement.name || clientElement.clientName;
          const phone = clientElement.phone || clientElement.phoneNumber;
          const email = clientElement.email || clientElement.emailId;
          const inquiryTimeStr = clientElement.inquiryTime || clientElement.timeOfInquiry;
          
          // Validate required fields
          if (!uniqueId || !name || !phone || !email || !inquiryTimeStr) {
            console.error("Missing required client fields", { uniqueId, name, phone, email, inquiryTimeStr });
            continue;
          }
          
          // Parse inquiry time
          let inquiryTime: Date;
          try {
            inquiryTime = new Date(inquiryTimeStr);
            if (isNaN(inquiryTime.getTime())) {
              throw new Error("Invalid date format");
            }
          } catch (error) {
            console.error("Invalid inquiry time format", inquiryTimeStr);
            inquiryTime = new Date(); // Fallback to current time
          }
          
          clients.push({
            uniqueId,
            name,
            phone,
            email,
            inquiryTime,
            status: "new",
            assignedTo: null,
            isSettled: false,
          });
        } catch (error) {
          console.error("Error parsing client element", error);
          // Continue with next client
        }
      }
      
      return { success: true, clients };
    }
    
    return { success: false, error: "Invalid XML format: Missing Leads/Lead elements or clients/client elements" };
  } catch (error) {
    console.error("Error parsing client XML", error);
    return { success: false, error: "Failed to parse XML data" };
  }
}

export async function parsePropertyXML(xmlData: string) {
  try {
    const result = await parseXml(xmlData, { explicitArray: false });
    
    // Check for Inventory format (from flat_inventory.xml)
    if (result.Inventory && result.Inventory.Flat) {
      const flatElements = Array.isArray(result.Inventory.Flat) 
        ? result.Inventory.Flat 
        : [result.Inventory.Flat];
      
      const properties: InsertProperty[] = [];
      
      for (const flat of flatElements) {
        try {
          // Extract property data from XML elements
          const uniqueId = flat.FlatID;
          const flatType = flat.Type;
          const builderName = flat.BuilderName;
          const flatNumber = flat.FlatNumber;
          const address = flat.Address;
          
          // Validate required fields
          if (!uniqueId || !flatType || !builderName || !flatNumber || !address) {
            console.error("Missing required property fields", { uniqueId, flatType, builderName, flatNumber, address });
            continue;
          }
          
          properties.push({
            uniqueId,
            flatType,
            builderName,
            flatNumber,
            address,
            isAvailable: true,
          });
        } catch (error) {
          console.error("Error parsing flat element", error);
          // Continue with next property
        }
      }
      
      return { success: true, properties };
    }
    
    // Traditional format check (fallback)
    if (result.properties && result.properties.property) {
      const propertyElements = Array.isArray(result.properties.property) 
        ? result.properties.property 
        : [result.properties.property];
      
      const properties: InsertProperty[] = [];
      
      for (const propertyElement of propertyElements) {
        try {
          // Extract property data from XML elements
          const uniqueId = propertyElement.uniqueId || propertyElement.id || propertyElement.flatId;
          const flatType = propertyElement.flatType || propertyElement.type;
          const builderName = propertyElement.builderName || propertyElement.builder;
          const flatNumber = propertyElement.flatNumber || propertyElement.number;
          const address = propertyElement.address;
          
          // Validate required fields
          if (!uniqueId || !flatType || !builderName || !flatNumber || !address) {
            console.error("Missing required property fields", { uniqueId, flatType, builderName, flatNumber, address });
            continue;
          }
          
          properties.push({
            uniqueId,
            flatType,
            builderName,
            flatNumber,
            address,
            isAvailable: true,
          });
        } catch (error) {
          console.error("Error parsing property element", error);
          // Continue with next property
        }
      }
      
      return { success: true, properties };
    }
    
    return { success: false, error: "Invalid XML format: Missing Inventory/Flat elements or properties/property elements" };
  } catch (error) {
    console.error("Error parsing property XML", error);
    return { success: false, error: "Failed to parse XML data" };
  }
}
