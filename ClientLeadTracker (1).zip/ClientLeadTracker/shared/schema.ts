import { pgTable, text, serial, integer, timestamp, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Users table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull().unique(),
  role: text("role").notNull().default("employee"), // manager or employee
  name: text("name").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  email: true,
  role: true,
  name: true,
});

// Client leads table
export const clients = pgTable("clients", {
  id: serial("id").primaryKey(),
  uniqueId: text("unique_id").notNull().unique(),
  name: text("name").notNull(),
  phone: text("phone").notNull(),
  email: text("email").notNull(),
  inquiryTime: timestamp("inquiry_time").notNull(),
  status: text("status").notNull().default("new"), // new, cold, warm, hot
  assignedTo: integer("assigned_to").references(() => users.id),
  isSettled: boolean("is_settled").notNull().default(false),
});

export const insertClientSchema = createInsertSchema(clients).pick({
  uniqueId: true,
  name: true,
  phone: true,
  email: true,
  inquiryTime: true,
  status: true,
  assignedTo: true,
  isSettled: true,
});

// Property data table
export const properties = pgTable("properties", {
  id: serial("id").primaryKey(),
  uniqueId: text("unique_id").notNull().unique(),
  flatType: text("flat_type").notNull(), // 2BHK, 3BHK, etc.
  builderName: text("builder_name").notNull(),
  flatNumber: text("flat_number").notNull(),
  address: text("address").notNull(),
  isAvailable: boolean("is_available").notNull().default(true),
});

export const insertPropertySchema = createInsertSchema(properties).pick({
  uniqueId: true,
  flatType: true,
  builderName: true,
  flatNumber: true,
  address: true,
  isAvailable: true,
});

// Client-Property interactions table
export const interactions = pgTable("interactions", {
  id: serial("id").primaryKey(),
  clientId: integer("client_id").notNull().references(() => clients.id),
  employeeId: integer("employee_id").notNull().references(() => users.id),
  interactionType: text("interaction_type").notNull(), // call, email, site-visit, etc.
  status: text("status").notNull(), // cold, warm, hot
  notes: text("notes"),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
});

export const insertInteractionSchema = createInsertSchema(interactions).pick({
  clientId: true,
  employeeId: true,
  interactionType: true,
  status: true,
  notes: true,
  timestamp: true,
});

// Follow-up table
export const followUps = pgTable("follow_ups", {
  id: serial("id").primaryKey(),
  clientId: integer("client_id").notNull().references(() => clients.id),
  employeeId: integer("employee_id").notNull().references(() => users.id),
  scheduledTime: timestamp("scheduled_time").notNull(),
  completed: boolean("completed").notNull().default(false),
  notes: text("notes"),
});

export const insertFollowUpSchema = createInsertSchema(followUps).pick({
  clientId: true,
  employeeId: true,
  scheduledTime: true,
  completed: true,
  notes: true,
});

// Site visits table
export const siteVisits = pgTable("site_visits", {
  id: serial("id").primaryKey(),
  clientId: integer("client_id").notNull().references(() => clients.id),
  propertyId: integer("property_id").notNull().references(() => properties.id),
  employeeId: integer("employee_id").notNull().references(() => users.id),
  scheduledTime: timestamp("scheduled_time").notNull(),
  completed: boolean("completed").notNull().default(false),
  notes: text("notes"),
});

export const insertSiteVisitSchema = createInsertSchema(siteVisits).pick({
  clientId: true,
  propertyId: true,
  employeeId: true,
  scheduledTime: true,
  completed: true,
  notes: true,
});

// Settlements table
export const settlements = pgTable("settlements", {
  id: serial("id").primaryKey(),
  clientId: integer("client_id").notNull().references(() => clients.id),
  propertyId: integer("property_id").notNull().references(() => properties.id),
  employeeId: integer("employee_id").notNull().references(() => users.id),
  settlementDate: timestamp("settlement_date").notNull().defaultNow(),
  notes: text("notes"),
});

export const insertSettlementSchema = createInsertSchema(settlements).pick({
  clientId: true,
  propertyId: true,
  employeeId: true,
  settlementDate: true,
  notes: true,
});

// Define relations
export const usersRelations = relations(users, ({ many }) => ({
  clients: many(clients),
  interactions: many(interactions),
  followUps: many(followUps),
  siteVisits: many(siteVisits),
  settlements: many(settlements),
}));

export const clientsRelations = relations(clients, ({ one, many }) => ({
  assignedEmployee: one(users, {
    fields: [clients.assignedTo],
    references: [users.id],
  }),
  interactions: many(interactions),
  followUps: many(followUps),
  siteVisits: many(siteVisits),
  settlements: many(settlements),
}));

export const propertiesRelations = relations(properties, ({ many }) => ({
  siteVisits: many(siteVisits),
  settlements: many(settlements),
}));

export const interactionsRelations = relations(interactions, ({ one }) => ({
  client: one(clients, {
    fields: [interactions.clientId],
    references: [clients.id],
  }),
  employee: one(users, {
    fields: [interactions.employeeId],
    references: [users.id],
  }),
}));

export const followUpsRelations = relations(followUps, ({ one }) => ({
  client: one(clients, {
    fields: [followUps.clientId],
    references: [clients.id],
  }),
  employee: one(users, {
    fields: [followUps.employeeId],
    references: [users.id],
  }),
}));

export const siteVisitsRelations = relations(siteVisits, ({ one }) => ({
  client: one(clients, {
    fields: [siteVisits.clientId],
    references: [clients.id],
  }),
  property: one(properties, {
    fields: [siteVisits.propertyId],
    references: [properties.id],
  }),
  employee: one(users, {
    fields: [siteVisits.employeeId],
    references: [users.id],
  }),
}));

export const settlementsRelations = relations(settlements, ({ one }) => ({
  client: one(clients, {
    fields: [settlements.clientId],
    references: [clients.id],
  }),
  property: one(properties, {
    fields: [settlements.propertyId],
    references: [properties.id],
  }),
  employee: one(users, {
    fields: [settlements.employeeId],
    references: [users.id],
  }),
}));

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Client = typeof clients.$inferSelect;
export type InsertClient = z.infer<typeof insertClientSchema>;

export type Property = typeof properties.$inferSelect;
export type InsertProperty = z.infer<typeof insertPropertySchema>;

export type Interaction = typeof interactions.$inferSelect;
export type InsertInteraction = z.infer<typeof insertInteractionSchema>;

export type FollowUp = typeof followUps.$inferSelect;
export type InsertFollowUp = z.infer<typeof insertFollowUpSchema>;

export type SiteVisit = typeof siteVisits.$inferSelect;
export type InsertSiteVisit = z.infer<typeof insertSiteVisitSchema>;

export type Settlement = typeof settlements.$inferSelect;
export type InsertSettlement = z.infer<typeof insertSettlementSchema>;

// Custom schemas for form validations
export const loginSchema = z.object({
  username: z.string().min(1, "Username is required"),
  password: z.string().min(1, "Password is required"),
});

export type LoginData = z.infer<typeof loginSchema>;

// Status type for client leads
export const LeadStatusEnum = z.enum(["new", "cold", "warm", "hot"]);
export type LeadStatus = z.infer<typeof LeadStatusEnum>;

// Interaction type enum
export const InteractionTypeEnum = z.enum(["call", "email", "whatsapp", "site-visit", "office-visit"]);
export type InteractionType = z.infer<typeof InteractionTypeEnum>;
